# Anime TV

Anime TV is a Telegram bot and community platform for anime discovery, favorites, and announcements.

## Features

- Telegram user onboarding and profile tracking
- Anime catalog and title search
- Favorites management
- Admin catalog operations and announcements
- SQLite development database and PostgreSQL-ready configuration
- Async SQLAlchemy models and pytest coverage

## Quick start

1. Create a virtual environment and install dependencies:
   `python -m venv .venv`
   `./.venv/Scripts/python.exe -m pip install -r requirements.txt`
2. Copy `.env.example` to `.env` and set real values.
3. Run migrations (the project includes Alembic-ready configuration):
   `alembic upgrade head`
4. Start the bot:
   `python -m app.main`

## Keep the bot running on Windows

On the Windows computer that should host the bot, make sure `.env` contains a valid `BOT_TOKEN` and install the project dependencies. Then open PowerShell in the project folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install_windows_autostart.ps1
```

This registers an `AnimeTVBot` Task Scheduler task for the current Windows user. It starts the bot when that user signs in and retries after a failure. The installer also disables sleep while the computer is plugged into AC power and writes bot output to `logs\bot.log`. The computer must remain powered on, connected to the internet, and signed in; shutting down or losing internet prevents the bot from responding. To start the scheduled task immediately, use `Start-ScheduledTask -TaskName AnimeTVBot`.

## Run 24/7 on an Ubuntu VPS

A VPS keeps the bot online independently of your personal computer. Stop the Windows bot first so two instances do not poll Telegram at once:

```powershell
Stop-ScheduledTask -TaskName AnimeTVBot
```

Copy the project to `/opt/anime-tv` on an Ubuntu VPS, including `requirements.txt`, `app/`, and `deploy/`. Keep `.env`, `.venv/`, and local logs out of the upload. Create a temporary upload folder and copy the project from PowerShell:

```powershell
ssh user@YOUR_VPS_IP "mkdir -p /tmp/anime-tv"
scp -r .\app .\deploy .\requirements.txt .\pytest.ini user@YOUR_VPS_IP:/tmp/anime-tv/
```

Then connect with `ssh user@YOUR_VPS_IP` and run these commands on the VPS:

```sh
sudo install -d /opt/anime-tv /etc/anime-tv
sudo cp -r /tmp/anime-tv/app /tmp/anime-tv/deploy /tmp/anime-tv/requirements.txt /tmp/anime-tv/pytest.ini /opt/anime-tv/
sudo nano /etc/anime-tv/anime-tv.env
```

Put the real `BOT_TOKEN`, your personal Telegram user IDs in `ADMIN_IDS`, and the other required settings into `/etc/anime-tv/anime-tv.env`; do not commit or publish this file. Keep `DATABASE_URL` unset there so the service stores persistent data under `/var/lib/anime-tv/anime_tv.db`. To migrate the existing catalog/database, securely copy `anime_tv.db` to `/tmp/anime-tv/anime_tv.db` before running the installer. It imports the file only if no VPS database exists:

```powershell
scp .\anime_tv.db user@YOUR_VPS_IP:/tmp/anime-tv/anime_tv.db
```

Install and start the service:

```sh
sudo bash /opt/anime-tv/deploy/install_ubuntu.sh
```

The installer creates a restricted `anime-tv` system user, installs dependencies in a virtual environment, enables automatic startup after reboot, and restarts the service after failures. Check status and logs with:

```sh
sudo systemctl status anime-tv
sudo journalctl -u anime-tv -f
```

The VPS must stay powered on and have internet access. Only one instance should poll Telegram at a time.

## Environment variables

- `BOT_TOKEN`: Telegram bot token
- `GROUP_ID`: Optional group chat ID
- `ADMIN_IDS`: CSV list of Telegram IDs with admin rights
- `DATABASE_URL`: SQLAlchemy database URL
- `ANIME_API_BASE_URL`: Optional metadata provider base URL
- `ANIME_API_KEY`: Optional metadata API key
- `WEBHOOK_URL`: Optional webhook URL
- `WEBHOOK_SECRET`: Optional webhook secret

## Admin panel

Admin users listed in `ADMIN_IDS` can access the management panel with:

- `/admin` — open the admin dashboard
- `/stats` — view users, anime, announcement, and favorite totals
- **Anime qo‘shish** — paste the labeled fields in one message, review the preview, then confirm. Only `Nomi:` is required; optional fields can be omitted or set to `-`.
- **Anime tahrirlash / o‘chirish** — choose the anime by ID; deletion requires confirmation.
- **Fasl va qism qo‘shish** — enter an anime ID, season number, and episode links in `/admin`. Viewers can open an anime, select a season, then tap an episode link.
- **VIP muddat berish** — manually grant or extend VIP for a Telegram `@username` or ID. The admin chooses the duration in days (1–36,500); username lookup only works for users who have started the bot.
- **VIP chegirmalari** — set a 0–99% Stars discount separately for each package. A discount of 0 removes it; prices update in the buyer's VIP menu and invoice. The selected discount is kept with the invoice so changing a promotion does not invalidate an already-open invoice.
- **VIP sotib olish** in the main menu offers Telegram Stars invoices: 1 month (56 Stars), 3 months (132 Stars), 6 months (226 Stars), and 1 year (454 Stars), before any admin-configured discount. VIP is activated after Telegram confirms successful payment; a repeat payment update cannot grant VIP twice.
- **E’lon yuborish** — review the recipient count, connected group, and message, then confirm to broadcast it to active users who have started the bot and enabled notifications, plus the configured group. Premium custom-emoji entities in the submitted text are preserved when previewing and delivering the announcement. Set `GROUP_ID` in `.env`; the bot must be a group member and allowed to send messages. The result reports private and group delivery status. Telegram does not let bots start private chats with users, so invite them to open the bot and press `/start` first.
- `/add_anime`, `/delete_anime`, and `/announce` — start the corresponding guided flow directly
- `/cancel` — cancel an active admin flow
- `/emoji_ids` followed by one or more Telegram Premium custom emojis — show their IDs

The Telegram `/` command menu lists common user commands for everyone in private chats and groups. Admin commands are added only for positive Telegram user IDs in `ADMIN_IDS` (in their private chat and, when `GROUP_ID` is set, for those admin users in that group). Put personal Telegram user IDs—not group IDs—in `ADMIN_IDS`. Telegram refreshes these commands when the bot starts.

The welcome message and main menu are available in Uzbek, Russian, and English. Users can change their language from **Tilni o'zgartirish**; the selection is saved to their profile. Other bot sections and the admin panel remain in Uzbek.

Premium emoji IDs are applied automatically to matching bot message text and inline keyboard button icons. Anime details use the configured Premium emojis for their title, metadata, and description heading; descriptions remain separate from the metadata. Inline keyboard buttons use Telegram's `primary`, `success`, and `danger` styles for color accents; buttons with no style use the Telegram client's default appearance. Exact shades depend on the Telegram client and its theme. Telegram requires the bot owner to have Telegram Premium or the bot to have a purchased username for custom button icons.

The database creates the anime season, episode, VIP membership, and VIP payment tables at startup; VIP discounts are stored in the existing bot settings table. Telegram requires digital goods and services sold inside bots to use Telegram Stars; Payme, Click, Uzum, Visa, and Xummo are not used for in-bot VIP checkout.

Season entry example:

```text
Anime ID: 12
Fasl: 1
Nomi: 1-fasl
Qism: 1 | https://example.com/episode-1
Qism: 2 | Qism nomi | https://example.com/episode-2
```

## Testing

Run:

`pytest`

The project uses an isolated SQLite in-memory database for unit tests.
