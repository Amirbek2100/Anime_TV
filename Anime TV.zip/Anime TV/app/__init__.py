"""Anime TV application package."""

__all__ = ["app"]
