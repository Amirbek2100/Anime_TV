from __future__ import annotations

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode

from app.config import get_settings


async def create_bot_and_dispatcher() -> tuple[Bot, Dispatcher]:
    settings = get_settings()
    bot = Bot(token=settings.bot_token, parse_mode=ParseMode.HTML)
    dp = Dispatcher()
    return bot, dp
