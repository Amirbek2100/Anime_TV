from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

from pydantic import Field, ValidationError, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(Path(__file__).resolve().parents[1] / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_env: str = Field(default="development", alias="APP_ENV")
    bot_token: str = Field(default="", alias="BOT_TOKEN")
    group_id: int | None = Field(default=None, alias="GROUP_ID")
    admin_ids: list[int] = Field(default_factory=list, alias="ADMIN_IDS")
    database_url: str = Field(default="sqlite+aiosqlite:///./anime_tv.db", alias="DATABASE_URL")
    anime_api_base_url: str = Field(default="https://api.jikan.moe/v4", alias="ANIME_API_BASE_URL")
    anime_api_key: str = Field(default="", alias="ANIME_API_KEY")
    webhook_url: str | None = Field(default=None, alias="WEBHOOK_URL")
    webhook_secret: str | None = Field(default=None, alias="WEBHOOK_SECRET")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    @field_validator("admin_ids", mode="before")
    @classmethod
    def parse_admin_ids(cls, value: Any) -> list[int]:
        if value in (None, "", []):
            return []
        if isinstance(value, str):
            values = value.split(",")
            return [int(v.strip()) for v in values if v.strip()]
        if isinstance(value, list):
            return [int(v) for v in value]
        return [int(value)]

    @field_validator("bot_token")
    @classmethod
    def validate_bot_token(cls, value: str) -> str:
        if not value or not value.strip():
            raise ValueError("BOT_TOKEN is required")
        return value.strip()

    @property
    def is_production(self) -> bool:
        return self.app_env.lower() == "production"


def validate_settings() -> Settings:
    try:
        settings = Settings()
    except ValidationError as exc:
        raise ValueError(f"Invalid configuration: {exc}") from exc

    if not settings.bot_token:
        raise ValueError("BOT_TOKEN is required")
    if settings.group_id is not None and settings.group_id == 0:
        raise ValueError("GROUP_ID must be a valid Telegram chat ID when provided")
    if settings.database_url.strip() == "":
        raise ValueError("DATABASE_URL is required")
    return settings


@lru_cache(maxsize=1)
def _get_cached_settings() -> Settings:
    return validate_settings()


def get_settings() -> Settings:
    return _get_cached_settings()


get_settings.cache_clear = _get_cached_settings.cache_clear
get_settings.cache_info = _get_cached_settings.cache_info
