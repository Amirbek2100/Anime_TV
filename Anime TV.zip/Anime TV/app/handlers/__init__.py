from app.handlers.start import router as start_router
from app.handlers.menu import router as menu_router
from app.handlers.anime import router as anime_router
from app.handlers.search import router as search_router
from app.handlers.favorites import router as favorites_router
from app.handlers.profile import router as profile_router
from app.handlers.announcements import router as announcements_router
from app.handlers.admin import router as admin_router
from app.handlers.moderation import router as moderation_router
from app.handlers.callbacks import router as callbacks_router

__all__ = [
    'start_router',
    'menu_router',
    'anime_router',
    'search_router',
    'favorites_router',
    'profile_router',
    'announcements_router',
    'admin_router',
    'moderation_router',
    'callbacks_router',
]
