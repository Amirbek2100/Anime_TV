from __future__ import annotations

import asyncio
import logging
import re
from typing import TypedDict
from urllib.parse import urlsplit

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.exceptions import TelegramAPIError
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message, MessageEntity
from sqlalchemy import func, select

from app.config import get_settings
from app.database.models import Favorite
from app.database.session import get_session_factory
from app.services.anime_service import AnimeService
from app.services.announcement_service import AnnouncementService
from app.services.season_service import SeasonService
from app.services.user_service import UserService
from app.services.vip_service import VIP_PLANS, VipPlan, VipService
from app.states.admin_states import AdminAnimeState
from app.utils.premium_emojis import premium_button

router = Router()
logger = logging.getLogger(__name__)

ANIME_FORM_PROMPT = (
    'Anime ma’lumotlarini bitta xabarda yuboring:\n\n'
    'Nomi: Naruto\n'
    'Tavsif: Ninja bo‘lishni orzu qilgan Naruto haqida\n'
    'Yil: 2002\n'
    'Janrlar: Action, Adventure\n'
    'Poster: https://example.com/poster.jpg\n'
    'Havola: https://example.com/anime\n\n'
    'Faqat nomi majburiy. Qolgan qatorlarni tashlab ketish yoki “-” yozish mumkin.\n'
    'Bekor qilish: /cancel'
)

SEASON_FORM_PROMPT = (
    'Anime fasli va qismlarini bitta xabarda yuboring:\n\n'
    'Anime ID: 12\n'
    'Fasl: 1\n'
    'Nomi: 1-fasl\n'
    'Qism: 1 | https://example.com/episode-1\n'
    'Qism: 2 | Qism nomi | https://example.com/episode-2\n\n'
    'Har bir Qism qatorida raqam va havola majburiy. Havola http yoki https bo‘lsin.\n'
    'Bekor qilish: /cancel'
)
TELEGRAM_USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{5,32}$")


class AnimeForm(TypedDict):
    title: str
    description: str | None
    release_year: int | None
    genres: list[str]
    poster_url: str | None
    authorized_link: str | None


class SeasonForm(TypedDict):
    anime_id: int
    number: int
    title: str
    episodes: list[tuple[int, str | None, str]]


def _optional_text(value: str | None) -> str | None:
    cleaned = (value or '').strip()
    return cleaned if cleaned and cleaned not in {'-', '—'} else None


def parse_anime_form(text: str) -> AnimeForm:
    fields = {
        "title": "title",
        "nomi": "title",
        "name": "title",
        "description": "description",
        "tavsif": "description",
        "izoh": "description",
        "year": "release_year",
        "yil": "release_year",
        "release_year": "release_year",
        "genres": "genres",
        "janr": "genres",
        "janrlar": "genres",
        "poster": "poster_url",
        "poster_url": "poster_url",
        "link": "authorized_link",
        "havola": "authorized_link",
    }
    values: dict[str, object] = {
        "description": None,
        "release_year": None,
        "genres": [],
        "poster_url": None,
        "authorized_link": None,
    }

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if ":" not in line:
            if "title" in values:
                raise ValueError("Har bir qatorni Maydon: qiymat shaklida yozing.")
            values["title"] = line
            continue

        raw_key, raw_value = line.split(":", maxsplit=1)
        key = fields.get(raw_key.strip().casefold())
        if key is None:
            raise ValueError(f"Noma'lum maydon: {raw_key.strip()}")
        value = raw_value.strip()
        if key == "title":
            values[key] = value
        elif key == "release_year":
            if value and value not in {"-", "—"}:
                try:
                    year = int(value)
                except ValueError as exc:
                    raise ValueError("Yil son bo‘lishi kerak.") from exc
                if not 1880 <= year <= 2100:
                    raise ValueError("Yil 1880 va 2100 orasida bo‘lishi kerak.")
                values[key] = year
        elif key == "genres":
            values[key] = [
                genre.strip()
                for genre in value.split(",")
                if genre.strip() and genre.strip() not in {"-", "—"}
            ]
        else:
            values[key] = _optional_text(value)

    title = values.get("title")
    if not isinstance(title, str) or not title.strip():
        raise ValueError("Anime nomi majburiy. Nomi: Naruto shaklida kiriting.")
    description = values.get("description")
    release_year = values.get("release_year")
    genres = values.get("genres")
    poster_url = values.get("poster_url")
    authorized_link = values.get("authorized_link")
    if not isinstance(description, str) and description is not None:
        raise ValueError("Tavsif maydoni matn bo‘lishi kerak.")
    if not isinstance(release_year, int) and release_year is not None:
        raise ValueError("Yil son bo‘lishi kerak.")
    if not isinstance(genres, list) or not all(isinstance(item, str) for item in genres):
        raise ValueError("Janrlar vergul bilan ajratilgan matn bo‘lishi kerak.")
    if not isinstance(poster_url, str) and poster_url is not None:
        raise ValueError("Poster maydoni matn bo‘lishi kerak.")
    if not isinstance(authorized_link, str) and authorized_link is not None:
        raise ValueError("Havola maydoni matn bo‘lishi kerak.")
    return {
        "title": title.strip(),
        "description": description,
        "release_year": release_year,
        "genres": genres,
        "poster_url": poster_url,
        "authorized_link": authorized_link,
    }


def parse_season_form(text: str) -> SeasonForm:
    values: dict[str, str] = {}
    episodes: list[tuple[int, str | None, str]] = []
    for line in text.splitlines():
        if not line.strip():
            continue
        if ":" not in line:
            raise ValueError("Qatorlarni Maydon: qiymat shaklida kiriting.")
        raw_key, raw_value = line.split(":", maxsplit=1)
        key = raw_key.strip().casefold()
        value = raw_value.strip()
        if key in {"anime id", "anime_id", "id"}:
            values["anime_id"] = value
        elif key in {"fasl", "season"}:
            values["number"] = value
        elif key in {"nomi", "name", "title"}:
            values["title"] = value
        elif key in {"qism", "episode"}:
            parts = [part.strip() for part in value.split("|")]
            if len(parts) == 2:
                raw_number, url = parts
                episode_title = None
            elif len(parts) == 3:
                raw_number, episode_title, url = parts
            else:
                raise ValueError(
                    "Qism formati: Qism: 1 | URL yoki Qism: 1 | Nomi | URL."
                )
            if not raw_number.isdecimal() or int(raw_number) < 1:
                raise ValueError("Qism raqami musbat son bo‘lishi kerak.")
            parsed_url = urlsplit(url)
            if parsed_url.scheme not in {"http", "https"} or not parsed_url.netloc:
                raise ValueError("Qism havolasi http:// yoki https:// bilan boshlansin.")
            if len(url) > 1000:
                raise ValueError("Qism havolasi 1000 belgidan oshmasligi kerak.")
            if episode_title and len(episode_title) > 255:
                raise ValueError("Qism nomi 255 belgidan oshmasligi kerak.")
            episodes.append((int(raw_number), episode_title or None, url))
        else:
            raise ValueError(f"Noma'lum maydon: {raw_key.strip()}")

    raw_anime_id = values.get("anime_id", "")
    raw_number = values.get("number", "")
    if not raw_anime_id.isdecimal() or int(raw_anime_id) < 1:
        raise ValueError("Anime ID musbat son bo‘lishi kerak.")
    if not raw_number.isdecimal() or int(raw_number) < 1:
        raise ValueError("Fasl raqami musbat son bo‘lishi kerak.")
    title = values.get("title") or f"{raw_number}-fasl"
    if not title.strip():
        raise ValueError("Fasl nomi bo‘sh bo‘lishi mumkin emas.")
    if len(title.strip()) > 255:
        raise ValueError("Fasl nomi 255 belgidan oshmasligi kerak.")
    if not episodes:
        raise ValueError("Kamida bitta Qism qatori kiriting.")
    episode_numbers = [number for number, _, _ in episodes]
    if len(episode_numbers) != len(set(episode_numbers)):
        raise ValueError("Qism raqamlari takrorlanmasin.")
    if len(episodes) > 100:
        raise ValueError("Bir faslga eng ko‘pi bilan 100 ta qism kiriting.")
    episodes.sort(key=lambda episode: episode[0])
    return {
        "anime_id": int(raw_anime_id),
        "number": int(raw_number),
        "title": title.strip(),
        "episodes": episodes,
    }


def is_admin(telegram_id: int | None) -> bool:
    if telegram_id is None:
        return False
    return telegram_id in get_settings().admin_ids


def build_admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            premium_button('Statistika', 'stats', 'admin_stats'),
            premium_button('E\'lon yuborish', 'announcement', 'admin_announce', style='success'),
        ],
        [
            premium_button('Anime qo\'shish', 'add', 'admin_add_anime', style='success'),
            premium_button('Anime o\'chirish', 'delete', 'admin_delete_anime', style='danger'),
        ],
        [
            premium_button('Anime tahrirlash', 'edit', 'admin_edit_anime'),
            premium_button('Anime ro\'yxati', 'list', 'admin_list_anime'),
        ],
        [
            premium_button('Fasl va qism qo\'shish', 'recent', 'admin_add_season', style='success'),
            premium_button('VIP muddat berish', 'favorites', 'admin_grant_vip', style='success'),
        ],
        [
            premium_button('VIP chegirmalari', 'favorites', 'admin_vip_discounts'),
        ],
    ])


def build_admin_vip_discounts_keyboard(
    plans: list[VipPlan],
) -> InlineKeyboardMarkup:
    rows = [
        [
            premium_button(
                f'{plan.title}: {plan.discount_percent}% chegirma — {plan.stars} ⭐',
                'favorites',
                f'admin_vip_discount:{plan.key}',
                style='primary',
            )
        ]
        for plan in plans
    ]
    rows.append([premium_button('Admin menyu', 'brand', 'admin_menu')])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_edit_fields_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            premium_button('Nomi', 'edit', 'admin_edit_field:title'),
            premium_button('Tavsifi', 'edit', 'admin_edit_field:description'),
        ],
        [
            premium_button('Yili', 'edit', 'admin_edit_field:release_year'),
            premium_button('Janrlari', 'edit', 'admin_edit_field:genres'),
        ],
        [
            premium_button('Poster', 'edit', 'admin_edit_field:poster_url'),
            premium_button('Havola', 'edit', 'admin_edit_field:authorized_link'),
        ],
        [
            premium_button('Holati', 'edit', 'admin_edit_field:status'),
            premium_button('Yosh chegarasi', 'edit', 'admin_edit_field:age_rating'),
        ],
        [premium_button('Bekor qilish', 'delete', 'admin_cancel_action', style='danger')],
    ])


def build_confirmation_menu(
    confirm_data: str,
    confirm_text: str,
) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        premium_button(
            confirm_text,
            'favorites',
            confirm_data,
            style='danger' if confirm_data == 'admin_confirm_delete' else 'success',
        ),
        premium_button('Bekor qilish', 'delete', 'admin_cancel_action', style='danger'),
    ]])


async def _send_announcement_to_chat(
    bot: Bot,
    text: str,
    chat_id: int,
    target: str,
    entities: list[MessageEntity] | None = None,
) -> bool:
    try:
        await bot.send_message(
            chat_id=chat_id,
            text=text,
            entities=entities or None,
            parse_mode=None,
        )
    except TelegramAPIError as exc:
        logger.warning(
            'Announcement delivery to %s failed: %s',
            target,
            type(exc).__name__,
        )
        return False
    return True


async def ensure_admin(message: Message | CallbackQuery) -> bool:
    user_id = message.from_user.id if getattr(message, 'from_user', None) else None
    if not is_admin(user_id):
        if isinstance(message, CallbackQuery):
            await message.answer('🖤 Sizga admin paneliga kirish huquqi yo\'q.')
        else:
            await message.answer('🖤 Sizga admin paneliga kirish huquqi yo\'q.')
        return False
    return True


@router.message(Command('admin'))
async def admin_command(message: Message) -> None:
    if not await ensure_admin(message):
        return
    await message.answer(
        'Admin boshqaruv paneli\n\nKatalog, foydalanuvchilar va e\'lonlarni boshqarish uchun bo\'limni tanlang.',
        reply_markup=build_admin_menu(),
    )


@router.message(Command('cancel'))
async def cancel_admin_action_command(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    await state.clear()
    await message.answer(
        'Amal bekor qilindi. Admin menyu:',
        reply_markup=build_admin_menu(),
    )


@router.callback_query(F.data == 'admin_stats')
async def admin_stats_callback(callback: CallbackQuery) -> None:
    if not await ensure_admin(callback):
        return
    session_factory = get_session_factory()
    async with session_factory() as session:
        user_service = UserService(session)
        anime_service = AnimeService(session)
        announcement_service = AnnouncementService(session)
        total_users = await user_service.count_users()
        total_anime = await anime_service.count_anime()
        total_announcements = await announcement_service.count_announcements()
        total_favorites = await session.scalar(select(func.count()).select_from(Favorite))

    await callback.message.edit_text(
        f'😎 Admin statistikasi\n\n🌐 Foydalanuvchilar: {total_users}\n🏆 Anime soni: {total_anime}\n🎀 E\'lonlar: {total_announcements}\n❤️ Sevimlilar: {total_favorites or 0}',
        reply_markup=build_admin_menu(),
    )
    await callback.answer('Statistika yuklandi.')


@router.callback_query(F.data == 'admin_list_anime')
async def admin_list_anime_callback(callback: CallbackQuery) -> None:
    if not await ensure_admin(callback):
        return
    session_factory = get_session_factory()
    async with session_factory() as session:
        anime_list = await AnimeService(session).list_recent(limit=10)

    if not anime_list:
        await callback.message.edit_text(
            '🏆 Hozircha animelar yo\'q.',
            reply_markup=build_admin_menu(),
        )
        await callback.answer('Anime ro\'yxati bo\'sh.')
        return

    lines = ['🏆 Anime ro\'yxati']
    for anime in anime_list:
        lines.append(f'{anime.id}. {anime.title}')
    await callback.message.edit_text(
        '\n'.join(lines),
        reply_markup=build_admin_menu(),
    )
    await callback.answer('Ro\'yxat ko\'rsatildi.')


@router.callback_query(F.data == 'admin_add_season')
async def admin_add_season_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    await state.set_state(AdminAnimeState.waiting_season_details)
    await callback.message.edit_text(SEASON_FORM_PROMPT, parse_mode=None)
    await callback.answer()


@router.message(AdminAnimeState.waiting_season_details)
async def waiting_season_details_handler(
    message: Message,
    state: FSMContext,
) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    try:
        season_data = parse_season_form(message.text or "")
    except ValueError as exc:
        await message.answer(f"{exc}\n\nQaytadan yuboring yoki /cancel bosing.")
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        anime = await AnimeService(session).get_by_id(season_data["anime_id"])
    if anime is None:
        await message.answer("Bu ID bilan anime topilmadi. Anime ID ni tekshirib yuboring:")
        return

    await state.update_data(**season_data)
    await state.set_state(AdminAnimeState.season_preview)
    preview_episodes = season_data["episodes"][:10]
    episodes_preview = "\n".join(
        f"{number}-qism: {(title or 'Havola tayyor')[:60]}"
        for number, title, _ in preview_episodes
    )
    if len(season_data["episodes"]) > len(preview_episodes):
        episodes_preview += (
            f"\n... va yana {len(season_data['episodes']) - len(preview_episodes)} ta qism"
        )
    await message.answer(
        f"Anime: {anime.title}\n"
        f"Fasl: {season_data['number']} — {season_data['title']}\n"
        f"Qismlar:\n{episodes_preview}\n\n"
        "Saqlaymizmi?",
        parse_mode=None,
        reply_markup=build_confirmation_menu(
            "admin_confirm_add_season",
            "Faslni saqlash",
        ),
    )


@router.message(AdminAnimeState.season_preview)
async def season_preview_handler(message: Message) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    await message.answer(
        "Saqlash yoki bekor qilish uchun yuqoridagi tugmalardan foydalaning. "
        "Bekor qilish uchun /cancel yuboring."
    )


@router.callback_query(F.data == 'admin_confirm_add_season')
async def confirm_add_season_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    data = await state.get_data()
    anime_id = data.get("anime_id")
    season_number = data.get("number")
    season_title = data.get("title")
    raw_episodes = data.get("episodes")
    if (
        await state.get_state() != AdminAnimeState.season_preview.state
        or not isinstance(anime_id, int)
        or not isinstance(season_number, int)
        or not isinstance(season_title, str)
        or not isinstance(raw_episodes, list)
    ):
        await state.clear()
        await callback.answer("Faslni saqlash sessiyasi tugagan.", show_alert=True)
        return

    episodes: list[tuple[int, str | None, str]] = []
    for episode in raw_episodes:
        if (
            not isinstance(episode, (tuple, list))
            or len(episode) != 3
            or not isinstance(episode[0], int)
            or (episode[1] is not None and not isinstance(episode[1], str))
            or not isinstance(episode[2], str)
        ):
            await state.clear()
            await callback.answer("Qism ma’lumotlari noto‘g‘ri.", show_alert=True)
            return
        episodes.append((episode[0], episode[1], episode[2]))

    session_factory = get_session_factory()
    async with session_factory() as session:
        season_service = SeasonService(session)
        anime = await AnimeService(session).get_by_id(anime_id)
        existing = await season_service.get_season_by_number(
            anime_id,
            season_number,
        )
        season = None
        if anime is not None and existing is None:
            season = await season_service.create_season(
                anime_id=anime_id,
                number=season_number,
                title=season_title,
                episodes=episodes,
            )
        anime_title = anime.title if anime is not None else None

    if anime_title is None:
        await state.clear()
        await callback.answer("Anime topilmadi.", show_alert=True)
        return
    if season is None:
        await callback.answer(
            "Bu anime uchun shu raqamli fasl oldin qo‘shilgan.",
            show_alert=True,
        )
        return

    await state.clear()
    await callback.message.edit_text(
        f"{anime_title} — {season.title} saqlandi ({len(season.episodes)} qism).",
        parse_mode=None,
        reply_markup=build_admin_menu(),
    )
    await callback.answer("Fasl saqlandi.")


@router.callback_query(F.data == 'admin_grant_vip')
async def admin_grant_vip_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    await state.set_state(AdminAnimeState.waiting_vip_telegram_id)
    await callback.message.edit_text(
        "VIP bermoqchi bo‘lgan foydalanuvchining @username yoki Telegram ID sini yuboring.\n"
        "Masalan: @username yoki 123456789\n"
        "Username bo‘yicha topish uchun foydalanuvchi botda oldin /start bosgan bo‘lishi kerak.\n"
        "Keyingi xabarda VIP muddatini kunlarda tanlaysiz. Mavjud VIP muddati ustiga qo‘shiladi.\n"
        "Bekor qilish: /cancel",
        parse_mode=None,
    )
    await callback.answer()


@router.message(AdminAnimeState.waiting_vip_telegram_id)
async def grant_vip_to_user_handler(
    message: Message,
    state: FSMContext,
) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    identifier = (message.text or "").strip()
    if not identifier:
        await message.answer("Telegram ID yoki @username yuboring:")
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        vip_service = VipService(session)
        if identifier.isdecimal() and len(identifier) <= 20:
            telegram_id = int(identifier)
            user = (
                await vip_service.get_user_by_telegram_id(telegram_id)
                if telegram_id > 0
                else None
            )
        else:
            username = identifier.removeprefix("@")
            if not TELEGRAM_USERNAME_PATTERN.fullmatch(username):
                await message.answer(
                    "Username noto‘g‘ri. @username yoki musbat Telegram ID yuboring:"
                )
                return
            user = await vip_service.get_user_by_username(username)
            telegram_id = user.telegram_id if user is not None else 0

    if user is None:
        await message.answer(
            "Foydalanuvchi topilmadi. Telegram ID yoki @username ni tekshiring; "
            "username orqali topish uchun u botda /start bosgan bo‘lishi kerak:"
        )
        return

    await state.update_data(vip_telegram_id=telegram_id)
    await state.set_state(AdminAnimeState.waiting_vip_days)
    await message.answer(
        "VIP necha kunga berilsin? 1 dan 36500 gacha kun kiriting.\n"
        "Masalan: 30, 90, 180 yoki 365. Bekor qilish: /cancel",
        parse_mode=None,
    )


@router.message(AdminAnimeState.waiting_vip_days)
async def grant_vip_duration_handler(
    message: Message,
    state: FSMContext,
) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    raw_days = (message.text or "").strip()
    if (
        not raw_days.isdecimal()
        or len(raw_days) > 5
        or not 1 <= int(raw_days) <= 36500
    ):
        await message.answer("Muddat 1 dan 36500 gacha butun kun bo‘lishi kerak:")
        return

    data = await state.get_data()
    telegram_id = data.get("vip_telegram_id")
    if not isinstance(telegram_id, int) or telegram_id < 1:
        await state.clear()
        await message.answer(
            "VIP foydalanuvchisi topilmadi. Jarayonni qaytadan boshlang.",
            reply_markup=build_admin_menu(),
        )
        return

    days = int(raw_days)
    session_factory = get_session_factory()
    async with session_factory() as session:
        membership = await VipService(session).grant_membership(
            telegram_id,
            days=days,
        )
    await state.clear()
    if membership is None:
        await message.answer(
            "Foydalanuvchi topilmadi. Avval botda /start bosganini tekshiring.",
            reply_markup=build_admin_menu(),
        )
        return
    notified = await _send_announcement_to_chat(
        message.bot,
        f"VIP faollashtirildi! Amal qilish muddati: {membership.expires_at:%d.%m.%Y %H:%M}",
        telegram_id,
        "VIP user",
    )
    await message.answer(
        f"VIP {days} kunga faollashtirildi.\n"
        f"Amal qilish muddati: {membership.expires_at:%d.%m.%Y %H:%M}\n"
        f"Foydalanuvchiga xabar: {'yuborildi' if notified else 'yuborilmadi'}",
        parse_mode=None,
        reply_markup=build_admin_menu(),
    )


@router.callback_query(F.data == 'admin_menu')
async def admin_menu_callback(callback: CallbackQuery) -> None:
    if not await ensure_admin(callback):
        return
    await callback.message.edit_text(
        'Admin boshqaruv paneli',
        reply_markup=build_admin_menu(),
    )
    await callback.answer()


@router.callback_query(F.data == 'admin_vip_discounts')
async def admin_vip_discounts_callback(callback: CallbackQuery) -> None:
    if not await ensure_admin(callback):
        return
    session_factory = get_session_factory()
    async with session_factory() as session:
        plans = await VipService(session).get_purchase_plans()
    await callback.message.edit_text(
        "VIP Stars chegirmalari\n\n"
        "Tarifni tanlang va 0–99% chegirma kiriting. 0 chegirmani olib tashlaydi.\n"
        "Narxlar barcha xaridorlar uchun qo‘llanadi.",
        reply_markup=build_admin_vip_discounts_keyboard(plans),
        parse_mode=None,
    )
    await callback.answer()


@router.callback_query(F.data.startswith('admin_vip_discount:'))
async def admin_vip_discount_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    plan_key = callback.data.split(':', maxsplit=1)[1]
    if plan_key not in VIP_PLANS:
        await callback.answer('VIP tarifi topilmadi.', show_alert=True)
        return
    async with get_session_factory()() as session:
        plan = await VipService(session).get_purchase_plan(plan_key)
    if plan is None:
        await callback.answer('VIP tarifi topilmadi.', show_alert=True)
        return
    await state.update_data(vip_discount_plan=plan_key)
    await state.set_state(AdminAnimeState.waiting_vip_discount)
    await callback.message.edit_text(
        f"{plan.title} uchun hozirgi narx: {plan.stars} ⭐ "
        f"(chegirma {plan.discount_percent}%).\n"
        "Yangi chegirmani 0 dan 99 gacha foizda yuboring; 0 chegirmani olib tashlaydi.\n"
        "Bekor qilish: /cancel",
        parse_mode=None,
    )
    await callback.answer()


@router.message(AdminAnimeState.waiting_vip_discount)
async def set_vip_discount_handler(
    message: Message,
    state: FSMContext,
) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    raw_discount = (message.text or "").strip()
    if (
        not raw_discount.isdecimal()
        or len(raw_discount) > 2
        or not 0 <= int(raw_discount) <= 99
    ):
        await message.answer("Chegirmani 0 dan 99 gacha butun foizda kiriting:")
        return
    data = await state.get_data()
    plan_key = data.get("vip_discount_plan")
    if not isinstance(plan_key, str) or plan_key not in VIP_PLANS:
        await state.clear()
        await message.answer(
            "VIP tarifi topilmadi. Jarayonni qaytadan boshlang.",
            reply_markup=build_admin_menu(),
        )
        return
    discount_percent = int(raw_discount)
    session_factory = get_session_factory()
    async with session_factory() as session:
        vip_service = VipService(session)
        await vip_service.set_discount_percent(plan_key, discount_percent)
        plans = await vip_service.get_purchase_plans()
    await state.clear()
    await message.answer(
        f"{VIP_PLANS[plan_key].title} uchun chegirma {discount_percent}% qilib saqlandi.\n"
        "Yangi narx quyidagi VIP tariflarida qo‘llanadi:",
        reply_markup=build_admin_vip_discounts_keyboard(plans),
        parse_mode=None,
    )


@router.callback_query(F.data == 'admin_add_anime')
async def admin_add_anime_callback(callback: CallbackQuery, state: FSMContext) -> None:
    if not await ensure_admin(callback):
        return
    await state.set_state(AdminAnimeState.waiting_details)
    await callback.message.edit_text(ANIME_FORM_PROMPT, parse_mode=None)
    await callback.answer()


@router.message(AdminAnimeState.waiting_details)
async def waiting_anime_details_handler(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    try:
        data = parse_anime_form(message.text or "")
    except ValueError as exc:
        await message.answer(f'{exc}\n\nQaytadan yuboring yoki /cancel bosing.')
        return

    await state.update_data(**data)
    await state.set_state(AdminAnimeState.preview)
    await message.answer(
        'Kiritilgan anime:\n\n'
        f'Nomi: {data["title"]}\n'
        f'Tavsif: {data["description"] or "-"}\n'
        f'Yil: {data["release_year"] or "-"}\n'
        f'Janrlar: {", ".join(data["genres"]) or "-"}\n'
        f'Poster: {data["poster_url"] or "-"}\n'
        f'Havola: {data["authorized_link"] or "-"}\n\n'
        'Saqlaymizmi?',
        parse_mode=None,
        reply_markup=build_confirmation_menu(
            'admin_confirm_add',
            'Ha, saqlash',
        ),
    )


@router.callback_query(F.data == 'admin_confirm_add')
async def confirm_add_anime_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    data = await state.get_data()
    if await state.get_state() != AdminAnimeState.preview.state or not data.get('title'):
        await callback.answer('Saqlash sessiyasi tugagan. Anime qo‘shishni qayta boshlang.', show_alert=True)
        await state.clear()
        return
    session_factory = get_session_factory()
    async with session_factory() as session:
        anime = await AnimeService(session).create_anime(
            title=str(data['title']),
            description=data.get('description'),
            release_year=data.get('release_year'),
            genres=data.get('genres') or [],
            poster_url=data.get('poster_url'),
            authorized_link=data.get('authorized_link'),
        )
    await state.clear()
    await callback.message.edit_text(
        f'Anime “{anime.title}” katalogga saqlandi.',
        parse_mode=None,
        reply_markup=build_admin_menu(),
    )
    await callback.answer('Anime saqlandi.')


@router.callback_query(F.data == 'admin_cancel_action')
async def cancel_admin_action_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    await state.clear()
    await callback.message.edit_text(
        'Amal bekor qilindi. Admin menyu:',
        reply_markup=build_admin_menu(),
    )
    await callback.answer()


@router.message(AdminAnimeState.preview)
async def preview_handler(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    await message.answer(
        'Saqlash yoki bekor qilish uchun yuqoridagi tugmalardan foydalaning. '
        'Bekor qilish uchun /cancel yuboring.'
    )


@router.callback_query(F.data == 'admin_delete_anime')
async def admin_delete_anime_callback(callback: CallbackQuery, state: FSMContext) -> None:
    if not await ensure_admin(callback):
        return
    await state.set_state(AdminAnimeState.waiting_delete_id)
    await callback.message.edit_text(
        'O\'chirish uchun anime ID raqamini kiriting:',
        reply_markup=build_admin_menu(),
    )
    await callback.answer('O\'chirish rejimi faollashdi.')


@router.message(AdminAnimeState.waiting_delete_id)
async def waiting_delete_id_handler(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    try:
        anime_id = int((message.text or '').strip())
    except ValueError:
        await message.answer('ID son bo\'lishi kerak. Qayta kiriting:')
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        anime = await AnimeService(session).get_by_id(anime_id)

    if anime is None:
        await message.answer('🖤 Bunday anime topilmadi.')
        return

    await state.update_data(delete_anime_id=anime_id)
    await state.set_state(AdminAnimeState.delete_confirmation)
    await message.answer(
        f'“{anime.title}” animesi o‘chirilsinmi? Bu amal sevimlilardan ham olib tashlaydi.',
        parse_mode=None,
        reply_markup=build_confirmation_menu(
            'admin_confirm_delete',
            'Ha, o‘chirish',
        ),
    )


@router.callback_query(F.data == 'admin_confirm_delete')
async def confirm_delete_anime_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    data = await state.get_data()
    anime_id = data.get('delete_anime_id')
    if (
        await state.get_state() != AdminAnimeState.delete_confirmation.state
        or not isinstance(anime_id, int)
    ):
        await state.clear()
        await callback.answer('O‘chirish so‘rovi tugagan. Qaytadan boshlang.', show_alert=True)
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        deleted = await AnimeService(session).delete_anime(anime_id)

    await state.clear()
    await callback.message.edit_text(
        'Anime o‘chirildi.' if deleted else 'Anime topilmadi yoki avval o‘chirilgan.',
        reply_markup=build_admin_menu(),
    )
    await callback.answer()


@router.callback_query(F.data == 'admin_announce')
async def admin_announce_callback(callback: CallbackQuery, state: FSMContext) -> None:
    if not await ensure_admin(callback):
        return
    await state.set_state(AdminAnimeState.waiting_announcement)
    await callback.message.edit_text(
        '🎀 E\'lon matnini yuboring:',
        reply_markup=build_admin_menu(),
    )
    await callback.answer('E\'lon yuborish boshlandi.')


@router.message(AdminAnimeState.waiting_announcement)
async def waiting_announcement_handler(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    text = message.text or ''
    if not text.strip():
        await message.answer('🧐 E\'lon matni bo\'sh bo\'lishi mumkin emas. Qayta kiriting:')
        return
    if len(text) > 4096:
        await message.answer('E\'lon 4096 belgidan oshmasligi kerak. Qisqartirib qayta yuboring:')
        return

    session_factory = get_session_factory()
    group_id = get_settings().group_id
    async with session_factory() as session:
        recipient_count = len(
            await UserService(session).get_notification_recipients()
        )

    if recipient_count == 0 and group_id is None:
        await state.clear()
        await message.answer(
            'E’lon yuborilmadi: shaxsiy qabul qiluvchilar ham, ulangan guruh ham yo‘q.\n\n'
            'Foydalanuvchilar botga kirib /start bosgandan keyingina bot '
            'ularga shaxsiy xabar yubora oladi. Guruhga yuborish uchun .env '
            'faylida GROUP_ID ni sozlang.',
            parse_mode=None,
            reply_markup=build_admin_menu(),
        )
        return

    serialized_entities = [
        entity.model_dump(mode='json', exclude_none=True)
        for entity in message.entities or []
    ]
    await state.update_data(
        announcement_text=text,
        announcement_entities=serialized_entities,
    )
    await state.set_state(AdminAnimeState.announcement_preview)
    await message.answer(
        f'Qabul qiluvchilar: {recipient_count} ta faol foydalanuvchi.\n'
        'Shaxsiy xabar: faqat botda /start bosgan foydalanuvchilarga.\n'
        f'Ulangan guruh: {"bor" if group_id is not None else "sozlanmagan"}.\n'
        'E’lon matnini ko‘rib, pastdagi tugma orqali tasdiqlang.',
        parse_mode=None,
    )
    await message.answer(
        text,
        entities=message.entities,
        parse_mode=None,
        reply_markup=build_confirmation_menu(
            'admin_confirm_announcement',
            'Ha, yuborish',
        ),
    )


@router.callback_query(F.data == 'admin_confirm_announcement')
async def confirm_announcement_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    data = await state.get_data()
    announcement_text = data.get('announcement_text')
    raw_entities = data.get('announcement_entities', [])
    if (
        await state.get_state() != AdminAnimeState.announcement_preview.state
        or not isinstance(announcement_text, str)
        or not announcement_text.strip()
        or not isinstance(raw_entities, list)
        or not all(isinstance(entity, dict) for entity in raw_entities)
    ):
        await state.clear()
        await callback.answer('E’lon yuborish sessiyasi tugagan. Qaytadan boshlang.', show_alert=True)
        return
    announcement_entities = [
        MessageEntity.model_validate(entity)
        for entity in raw_entities
    ]

    session_factory = get_session_factory()
    group_id = get_settings().group_id
    async with session_factory() as session:
        recipients = await UserService(session).get_notification_recipients()
        if recipients or group_id is not None:
            await AnnouncementService(session).create_announcement(
                message=announcement_text,
                created_by=callback.from_user.id,
            )
    if not recipients and group_id is None:
        await state.clear()
        await callback.message.edit_text(
            'E’lon yuborilmadi: faol shaxsiy qabul qiluvchilar yoki ulangan guruh yo‘q. '
            'Guruhga yuborish uchun .env faylida GROUP_ID ni sozlang.',
            parse_mode=None,
            reply_markup=build_admin_menu(),
        )
        await callback.answer('Qabul qiluvchilar yo‘q.', show_alert=True)
        return
    await state.clear()
    await callback.answer('E’lon yuborish boshlandi.')

    sent = 0
    failed = 0
    for telegram_id in recipients:
        delivered = await _send_announcement_to_chat(
            callback.bot,
            announcement_text,
            telegram_id,
            'private user',
            announcement_entities,
        )
        if delivered:
            sent += 1
        else:
            failed += 1
        await asyncio.sleep(0.05)

    group_status = 'sozlanmagan'
    if group_id is not None:
        group_delivered = await _send_announcement_to_chat(
            callback.bot,
            announcement_text,
            group_id,
            'configured group',
            announcement_entities,
        )
        group_status = 'yuborildi' if group_delivered else 'yuborilmadi'

    result_text = (
        f'E’lon yuborish yakunlandi.\n\n'
        f'Shaxsiy xabarlar: {sent} ta yuborildi, {failed} ta yuborilmadi.\n'
        f'Guruh: {group_status}.'
    )
    if group_id is not None and group_status == 'yuborilmadi':
        result_text += (
            '\n\nGuruhga yuborilmadi. .env ichidagi GROUP_ID ni tekshiring '
            'va bot guruhdan xabar yubora olishini tasdiqlang.'
        )

    await callback.message.edit_text(
        result_text,
        parse_mode=None,
        reply_markup=build_admin_menu(),
    )


@router.callback_query(F.data == 'admin_edit_anime')
async def admin_edit_anime_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    await state.set_state(AdminAnimeState.waiting_edit_id)
    await callback.message.edit_text(
        'Tahrirlanadigan anime ID raqamini yuboring.\n'
        'ID ni /admin → Anime ro‘yxati bo‘limidan ko‘rishingiz mumkin.\n'
        'Bekor qilish: /cancel',
    )
    await callback.answer()


@router.message(AdminAnimeState.waiting_edit_id)
async def waiting_edit_id_handler(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    raw_id = (message.text or '').strip()
    if not raw_id.isdecimal():
        await message.answer('ID faqat raqam bo‘lishi kerak. Qaytadan yuboring:')
        return
    anime_id = int(raw_id)
    session_factory = get_session_factory()
    async with session_factory() as session:
        anime = await AnimeService(session).get_by_id(anime_id)
    if anime is None:
        await message.answer('Bu ID bilan anime topilmadi. Boshqa ID yuboring:')
        return
    await state.update_data(edit_anime_id=anime_id)
    await state.set_state(AdminAnimeState.waiting_edit_value)
    await message.answer(
        f'“{anime.title}” uchun qaysi ma’lumotni o‘zgartiramiz?',
        parse_mode=None,
        reply_markup=build_edit_fields_menu(),
    )


@router.callback_query(F.data.startswith('admin_edit_field:'))
async def choose_edit_field_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    if not await ensure_admin(callback):
        return
    field_name = callback.data.split(':', maxsplit=1)[1]
    allowed_fields = {
        'title',
        'description',
        'release_year',
        'genres',
        'poster_url',
        'authorized_link',
        'status',
        'age_rating',
    }
    data = await state.get_data()
    if (
        field_name not in allowed_fields
        or not isinstance(data.get('edit_anime_id'), int)
        or await state.get_state() != AdminAnimeState.waiting_edit_value.state
    ):
        await callback.answer('Tahrirlash sessiyasi tugagan. Qaytadan boshlang.', show_alert=True)
        await state.clear()
        return

    await state.update_data(edit_field=field_name)
    field_labels = {
        'title': 'yangi anime nomini',
        'description': 'yangi tavsifni',
        'release_year': 'yangi yilni yoki noma’lum bo‘lsa - belgisini',
        'genres': 'janrlarni vergul bilan',
        'poster_url': 'poster havolasini yoki olib tashlash uchun - belgisini',
        'authorized_link': 'rasmiy havolani yoki olib tashlash uchun - belgisini',
        'status': 'anime holatini yoki olib tashlash uchun - belgisini',
        'age_rating': 'yosh chegarasini yoki olib tashlash uchun - belgisini',
    }
    await callback.message.edit_text(
        f'{field_labels[field_name].capitalize()} yuboring.\nBekor qilish: /cancel',
        parse_mode=None,
        reply_markup=build_edit_fields_menu(),
    )
    await callback.answer()


@router.message(AdminAnimeState.waiting_edit_value)
async def waiting_edit_value_handler(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        return
    data = await state.get_data()
    anime_id = data.get('edit_anime_id')
    field_name = data.get('edit_field')
    if not isinstance(anime_id, int) or not isinstance(field_name, str):
        await state.clear()
        await message.answer('Tahrirlash sessiyasi tugadi. /admin orqali qaytadan boshlang.')
        return

    raw_value = (message.text or '').strip()
    updates: dict[str, str | int | None] = {}
    genres_update: list[str] | None = None
    if field_name == 'release_year':
        if raw_value in {'-', '—'}:
            updates = {'release_year': None}
        else:
            try:
                year = int(raw_value)
            except ValueError:
                await message.answer('Yil raqam bo‘lishi yoki - bo‘lishi kerak. Qaytadan yuboring:')
                return
            if not 1880 <= year <= 2100:
                await message.answer('Yil 1880 va 2100 orasida bo‘lishi kerak. Qaytadan yuboring:')
                return
            updates = {'release_year': year}
    elif field_name == 'genres':
        genres_update = [
            genre.strip()
            for genre in raw_value.split(',')
            if genre.strip() and genre.strip() not in {'-', '—'}
        ]
    elif field_name == 'title':
        if not raw_value:
            await message.answer('Anime nomi bo‘sh bo‘lishi mumkin emas. Qaytadan yuboring:')
            return
        updates = {'title': raw_value}
    else:
        updates = {field_name: _optional_text(raw_value)}

    session_factory = get_session_factory()
    async with session_factory() as session:
        anime_service = AnimeService(session)
        if genres_update is not None:
            updated = await anime_service.update_genres(
                anime_id,
                genres_update,
            )
        else:
            updated = await anime_service.update_anime(anime_id, **updates)
    await state.clear()
    await message.answer(
        'Anime ma’lumoti yangilandi.' if updated else 'Anime topilmadi.',
        reply_markup=build_admin_menu(),
    )


@router.message(Command('stats'))
async def stats_command(message: Message) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        await message.answer('🖤 Sizga statistika ko\'rish huquqi yo\'q.')
        return
    session_factory = get_session_factory()
    async with session_factory() as session:
        user_service = UserService(session)
        anime_service = AnimeService(session)
        announcement_service = AnnouncementService(session)
        total_users = await user_service.count_users()
        total_anime = await anime_service.count_anime()
        total_announcements = await announcement_service.count_announcements()
        total_favorites = await session.scalar(select(func.count()).select_from(Favorite))

    await message.answer(
        f'😎 Admin statistikasi\n\n🌐 Foydalanuvchilar: {total_users}\n🏆 Anime soni: {total_anime}\n🎀 E\'lonlar: {total_announcements}\n❤️ Sevimlilar: {total_favorites or 0}',
        reply_markup=build_admin_menu(),
    )


@router.message(Command('add_anime'))
async def add_anime_command(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        await message.answer('🖤 Sizga anime qo\'shishga ruxsat yo\'q.')
        return
    await state.set_state(AdminAnimeState.waiting_details)
    await message.answer(ANIME_FORM_PROMPT, parse_mode=None)


@router.message(Command('delete_anime'))
async def delete_anime_command(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        await message.answer('🖤 Sizga anime o\'chirishga ruxsat yo\'q.')
        return
    await state.set_state(AdminAnimeState.waiting_delete_id)
    await message.answer('O\'chirish uchun anime ID raqamini kiriting:')


@router.message(Command('announce'))
async def announce_command(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        await message.answer('🖤 Sizga e\'lon yuborishga ruxsat yo\'q.')
        return
    await state.set_state(AdminAnimeState.waiting_announcement)
    await message.answer('🎀 E\'lon matnini yuboring:')


@router.message(Command('edit_anime'))
async def edit_anime_command(message: Message) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        await message.answer('🖤 Sizga anime tahrirlashga ruxsat yo\'q.')
        return

    text = (message.text or '').strip()
    parts = text.split(maxsplit=3)
    if len(parts) < 4:
        await message.answer('Format: /edit_anime 12 title Naruto Shippuden\n\nYoki:\n/edit_anime 12 description Yangi ta\'rif')
        return

    try:
        anime_id = int(parts[1])
    except ValueError:
        await message.answer('Anime ID raqami son bo\'lishi kerak.')
        return

    field_name = parts[2].lower()
    new_value = parts[3]
    allowed_fields = {'title', 'description', 'status', 'age_rating', 'source', 'authorized_link'}
    if field_name not in allowed_fields:
        await message.answer(f'Noto\'g\'ri maydon. Mavjud maydonlar: {", ".join(sorted(allowed_fields))}')
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        service = AnimeService(session)
        updated = await service.update_anime(anime_id, **{field_name: new_value})

    if updated is None:
        await message.answer('🖤 Bunday anime topilmadi.')
        return

    await message.answer(f'🩷 #{anime_id} ID dagi anime {field_name} maydoni yangilandi.')


@router.message(Command('backup'))
async def backup_command(message: Message) -> None:
    if not is_admin(message.from_user.id if message.from_user else None):
        await message.answer('🖤 Sizga backup yaratishga ruxsat yo\'q.')
        return
    await message.answer('Ma\'lumotlar bazasi zaxiralandi.')
