from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.keyboards.anime import PAGE_SIZE, build_anime_selection_keyboard
from app.keyboards.main_menu import build_main_menu
from app.database.session import get_session_factory
from app.services.anime_service import AnimeService

router = Router()


@router.message(Command('anime'))
async def anime_command(message: Message) -> None:
    session_factory = get_session_factory()
    async with session_factory() as session:
        service = AnimeService(session)
        anime_list = await service.list_recent(limit=PAGE_SIZE)

    if not anime_list:
        await message.answer(
            '🏆 Anime katalogi hozircha bo\'sh. Adminlar tez orada yangi animelarni qo\'shadi.',
            reply_markup=build_main_menu(),
        )
        return

    lines = ['🏆 Anime katalogi']
    for index, anime in enumerate(anime_list, start=1):
        title = anime.title
        lines.append(f'{index}. 📀 {title}')
    await message.answer(
        '\n'.join(lines),
        parse_mode=None,
        reply_markup=build_anime_selection_keyboard(anime_list),
    )
