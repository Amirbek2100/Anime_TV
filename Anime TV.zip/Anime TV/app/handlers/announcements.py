from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command('about'))
async def about_command(message: Message) -> None:
    await message.answer('🎀 Anime TV — yangi animelarni topish, sevimlilarni saqlash va hamjamiyat bilan muloqot qilish platformasi.')


@router.message(Command('language'))
async def language_command(message: Message) -> None:
    await message.answer('🌐 Til sozlamalarini ochish uchun menyudagi “Tilni o\'zgartirish” tugmasini bosing.')


@router.message(Command('id'))
async def id_command(message: Message) -> None:
    if not message.from_user:
        await message.answer('Foydalanuvchi ma\'lumoti topilmadi.')
        return
    await message.answer(f'😎 Telegram ID: {message.from_user.id}')


@router.message(Command('emoji_ids'))
async def emoji_ids_command(message: Message) -> None:
    custom_emojis = [
        entity
        for entity in message.entities or []
        if entity.type == 'custom_emoji' and entity.custom_emoji_id
    ]
    if not custom_emojis:
        await message.answer(
            'Premium emoji ID topilmadi. /emoji_ids buyrug\'idan keyin '
            'Telegram Premium custom emoji yuboring.'
        )
        return

    lines = ['😎 Premium emoji ID’lari:']
    for index, entity in enumerate(custom_emojis, start=1):
        lines.append(f'{index}. {entity.custom_emoji_id}')
    lines.append(
        '\nUshbu ID’lar bot xabarlari va inline tugma ikonalarida ishlatiladi.'
    )
    await message.answer('\n'.join(lines))
