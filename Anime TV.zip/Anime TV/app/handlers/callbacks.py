from __future__ import annotations

import logging
from collections.abc import Sequence
from datetime import datetime

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.exceptions import TelegramAPIError
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
    SuccessfulPayment,
)

from app.database.models import Anime
from app.database.session import get_session_factory
from app.keyboards.anime import (
    PAGE_SIZE,
    build_anime_detail_keyboard,
    build_anime_list_keyboard,
    build_episode_list_keyboard,
    build_season_list_keyboard,
)
from app.keyboards.main_menu import build_main_menu
from app.keyboards.vip import build_vip_purchase_keyboard
from app.services.anime_service import AnimeService
from app.services.season_service import SeasonService
from app.services.user_service import UserService
from app.services.vip_service import (
    VIP_PLANS,
    VipService,
    parse_vip_invoice_payload,
)
from app.states.search_states import AnimeSearchState
from app.utils.localization import (
    SUPPORTED_LANGUAGES,
    get_text,
    normalize_language,
)
from app.utils.premium_emojis import PREMIUM_EMOJIS, premium_button

router = Router()
LIST_SECTIONS = {"catalog", "recent", "popular", "favorites"}


async def _edit_callback_message(
    callback: CallbackQuery,
    text: str,
    **kwargs,
) -> None:
    message = callback.message
    if message.photo:
        await message.edit_reply_markup(reply_markup=None)
        await message.answer(text, **kwargs)
        return
    await message.edit_text(text, **kwargs)


def _format_anime_list(
    title: str,
    anime_list: Sequence[Anime],
    total: int | None = None,
) -> str:
    if not anime_list:
        return f'{title}\n\nHozircha bu bo‘limda anime yo‘q.'
    lines = [title]
    if total is not None:
        lines.append(f'Jami: {total}')
    lines.append('')
    lines.extend(
        f'{index}. {anime.title}'
        for index, anime in enumerate(anime_list, start=1)
    )
    return '\n'.join(lines)


def _format_anime_detail(anime: Anime) -> str:
    genres = ", ".join(genre.name for genre in anime.genres) or "Ko‘rsatilmagan"
    details = [
        f"🏆 {anime.title}",
        "━━━━━━━━━━━━━━",
        f"📀 Yili: {anime.release_year or 'Noma’lum'}",
        f"👀 Janrlar: {genres}",
    ]
    if anime.alternative_title:
        details.append(f"🌐 Boshqa nomi: {anime.alternative_title}")
    if anime.status:
        details.append(f"🔝 Holati: {anime.status}")
    if anime.age_rating:
        details.append(f"🧐 Yosh chegarasi: {anime.age_rating}")
    if anime.description:
        details.extend(["", "🎀 QISQACHA", "──────────────", anime.description])
    return "\n".join(details)


async def _get_section_page(
    service: AnimeService,
    section: str,
    *,
    user_id: int,
    offset: int,
) -> tuple[list[Anime], int, str]:
    if section == "catalog":
        return (
            await service.get_all(limit=PAGE_SIZE, offset=offset),
            await service.count_anime(),
            "🏆 Anime katalogi",
        )
    if section == "popular":
        return (
            await service.get_popular(limit=PAGE_SIZE, offset=offset),
            await service.count_anime(),
            "👀 Mashhur animelar",
        )
    if section == "recent":
        return (
            await service.list_recent(limit=PAGE_SIZE, offset=offset),
            await service.count_anime(),
            "🔝 Yangi qo‘shilganlar",
        )
    anime_list, total = await service.get_favorites(
        user_id,
        limit=PAGE_SIZE,
        offset=offset,
    )
    return anime_list, total, "❤️ Sevimlilarim"


async def _show_anime_list(
    callback: CallbackQuery,
    state: FSMContext,
    *,
    section: str,
    offset: int = 0,
) -> None:
    await state.clear()
    session_factory = get_session_factory()
    async with session_factory() as session:
        anime_list, total, title = await _get_section_page(
            AnimeService(session),
            section,
            user_id=callback.from_user.id,
            offset=offset,
        )

    await _edit_callback_message(
        callback,
        _format_anime_list(title, anime_list, total),
        parse_mode=None,
        reply_markup=build_anime_list_keyboard(
            anime_list,
            section=section,
            offset=offset,
            total=total,
        ),
    )
    await callback.answer()


async def _show_anime_detail(
    callback: CallbackQuery,
    *,
    anime_id: int,
    section: str,
    return_offset: int = 0,
    answer_text: str | None = None,
) -> None:
    session_factory = get_session_factory()
    async with session_factory() as session:
        service = AnimeService(session)
        anime = await service.get_by_id(anime_id)
        if anime is None:
            await callback.answer('Anime topilmadi yoki o‘chirilgan.', show_alert=True)
            return
        is_favorite = await service.is_favorite(callback.from_user.id, anime_id)
        season_count = len(await SeasonService(session).list_seasons(anime_id))

    keyboard = build_anime_detail_keyboard(
        anime.id,
        section=section,
        is_favorite=is_favorite,
        return_offset=return_offset,
        favorite_list=section == "favorites",
        season_count=season_count,
    )
    if anime.authorized_link:
        keyboard.inline_keyboard.insert(
            0,
            [InlineKeyboardButton(
                text="Rasmiy havola",
                icon_custom_emoji_id=PREMIUM_EMOJIS["recent"],
                style="primary",
                url=anime.authorized_link,
            )],
        )
    await _edit_callback_message(
        callback,
        _format_anime_detail(anime),
        parse_mode=None,
        reply_markup=keyboard,
        disable_web_page_preview=True,
    )
    await callback.answer(answer_text)


@router.callback_query(F.data == "catalog")
async def catalog_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_anime_list(callback, state, section="catalog")


@router.callback_query(F.data == "search")
async def search_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AnimeSearchState.waiting_query)
    session_factory = get_session_factory()
    async with session_factory() as session:
        language = await UserService(session).get_preferred_language(
            callback.from_user.id
        )
    await _edit_callback_message(
        callback,
        "🔍 Qidiruv\n\nAnime nomini keyingi xabarda yuboring. Bekor qilish uchun menyu tugmasini bosing.",
        parse_mode=None,
        reply_markup=build_main_menu(language=language),
    )
    await callback.answer()


@router.callback_query(F.data == "popular")
async def popular_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_anime_list(callback, state, section="popular")


@router.callback_query(F.data == "recent")
async def recent_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_anime_list(callback, state, section="recent")


@router.callback_query(F.data == "favorites")
async def favorites_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_anime_list(callback, state, section="favorites")


@router.callback_query(F.data.startswith("list:"))
async def anime_list_page_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    _, section, raw_offset = callback.data.split(":", maxsplit=2)
    if section not in LIST_SECTIONS or not raw_offset.isdecimal():
        await callback.answer("Ro‘yxat so‘rovi noto‘g‘ri.", show_alert=True)
        return
    await _show_anime_list(
        callback,
        state,
        section=section,
        offset=int(raw_offset),
    )


@router.callback_query(F.data.startswith("anime:"))
async def anime_detail_callback(callback: CallbackQuery) -> None:
    parts = callback.data.split(":", maxsplit=3)
    if len(parts) != 4:
        await callback.answer("Anime so‘rovi noto‘g‘ri.", show_alert=True)
        return
    _, raw_id, section, raw_offset = parts
    if (
        section not in LIST_SECTIONS
        or not raw_id.isdecimal()
        or not raw_offset.isdecimal()
    ):
        await callback.answer("Anime so‘rovi noto‘g‘ri.", show_alert=True)
        return
    await _show_anime_detail(
        callback,
        anime_id=int(raw_id),
        section=section,
        return_offset=int(raw_offset),
    )


@router.callback_query(F.data.startswith("seasons:"))
async def anime_seasons_callback(callback: CallbackQuery) -> None:
    parts = callback.data.split(":", maxsplit=3)
    if len(parts) != 4:
        await callback.answer("Fasl so‘rovi noto‘g‘ri.", show_alert=True)
        return
    _, raw_anime_id, section, raw_offset = parts
    if (
        section not in LIST_SECTIONS
        or not raw_anime_id.isdecimal()
        or not raw_offset.isdecimal()
    ):
        await callback.answer("Fasl so‘rovi noto‘g‘ri.", show_alert=True)
        return

    anime_id = int(raw_anime_id)
    session_factory = get_session_factory()
    async with session_factory() as session:
        anime = await AnimeService(session).get_by_id(anime_id)
        if anime is None:
            await callback.answer("Anime topilmadi.", show_alert=True)
            return
        seasons = await SeasonService(session).list_seasons(anime_id)

    if not seasons:
        await callback.answer("Bu anime uchun fasllar hali qo‘shilmagan.", show_alert=True)
        return
    await _edit_callback_message(
        callback,
        f"📀 {anime.title} — fasllar\n\nFaslni tanlang:",
        parse_mode=None,
        reply_markup=build_season_list_keyboard(
            seasons,
            anime_id=anime_id,
            section=section,
            return_offset=int(raw_offset),
        ),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("season:"))
async def season_episodes_callback(callback: CallbackQuery) -> None:
    parts = callback.data.split(":", maxsplit=5)
    if len(parts) != 6:
        await callback.answer("Fasl so‘rovi noto‘g‘ri.", show_alert=True)
        return
    _, raw_season_id, raw_anime_id, section, raw_offset, raw_episode_offset = parts
    if (
        section not in LIST_SECTIONS
        or not raw_season_id.isdecimal()
        or not raw_anime_id.isdecimal()
        or not raw_offset.isdecimal()
        or not raw_episode_offset.isdecimal()
    ):
        await callback.answer("Fasl so‘rovi noto‘g‘ri.", show_alert=True)
        return

    anime_id = int(raw_anime_id)
    session_factory = get_session_factory()
    async with session_factory() as session:
        anime = await AnimeService(session).get_by_id(anime_id)
        season = await SeasonService(session).get_season(int(raw_season_id))
    if anime is None or season is None or season.anime_id != anime_id:
        await callback.answer("Fasl topilmadi.", show_alert=True)
        return

    await _edit_callback_message(
        callback,
        f"📀 {anime.title} — {season.title}\n"
        f"Qismlar: {len(season.episodes)}"
        f" (sahifa {int(raw_episode_offset) // 8 + 1})\n\n"
        "Ko‘rish uchun qismni tanlang:",
        parse_mode=None,
        reply_markup=build_episode_list_keyboard(
            season.episodes,
            offset=int(raw_episode_offset),
            season_id=season.id,
            anime_id=anime_id,
            section=section,
            return_offset=int(raw_offset),
        ),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("add_favorite:"))
async def add_favorite_callback(callback: CallbackQuery) -> None:
    parts = callback.data.split(":", maxsplit=3)
    if len(parts) != 4:
        await callback.answer("Sevimliga qo‘shish so‘rovi noto‘g‘ri.", show_alert=True)
        return
    _, raw_id, section, raw_offset = parts
    if section not in LIST_SECTIONS or not raw_id.isdecimal() or not raw_offset.isdecimal():
        await callback.answer("Sevimliga qo‘shish so‘rovi noto‘g‘ri.", show_alert=True)
        return
    anime_id = int(raw_id)
    session_factory = get_session_factory()
    async with session_factory() as session:
        service = AnimeService(session)
        if await service.get_by_id(anime_id) is None:
            await callback.answer("Anime topilmadi.", show_alert=True)
            return
        await service.add_favorite(callback.from_user.id, anime_id)
    await _show_anime_detail(
        callback,
        anime_id=anime_id,
        section=section,
        return_offset=int(raw_offset),
        answer_text="Sevimlilaringizga qo‘shildi.",
    )


@router.callback_query(F.data.startswith("remove_favorite:"))
async def remove_favorite_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    parts = callback.data.split(":", maxsplit=3)
    if len(parts) != 4:
        await callback.answer("Sevimlidan olib tashlash so‘rovi noto‘g‘ri.", show_alert=True)
        return
    _, raw_id, section, raw_offset = parts
    if section not in LIST_SECTIONS or not raw_id.isdecimal() or not raw_offset.isdecimal():
        await callback.answer("Sevimlidan olib tashlash so‘rovi noto‘g‘ri.", show_alert=True)
        return
    anime_id = int(raw_id)
    session_factory = get_session_factory()
    async with session_factory() as session:
        await AnimeService(session).remove_favorite(callback.from_user.id, anime_id)

    if section == "favorites":
        await _show_anime_list(
            callback,
            state,
            section="favorites",
            offset=int(raw_offset),
        )
    else:
        await _show_anime_detail(
            callback,
            anime_id=anime_id,
            section=section,
            return_offset=int(raw_offset),
            answer_text="Sevimlilaringizdan olib tashlandi.",
        )


@router.callback_query(F.data == "profile")
async def profile_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    session_factory = get_session_factory()
    async with session_factory() as session:
        user_service = UserService(session)
        anime_service = AnimeService(session)
        user = await user_service.get_user_by_telegram_id(callback.from_user.id)
        if user is None:
            user = await user_service.get_or_create_user(
                telegram_id=callback.from_user.id,
                username=callback.from_user.username,
                first_name=callback.from_user.first_name,
            )
        favorite_count = await anime_service.get_favorite_count(user.id)
        membership = await VipService(session).get_membership(callback.from_user.id)

    vip_status = (
        f"Faol, {membership.expires_at:%d.%m.%Y} gacha"
        if membership and membership.expires_at > datetime.now()
        else "Faol emas"
    )
    await _edit_callback_message(
        callback,
        f'✏️ Mening profilim\n\n'
        f'Telegram ID: {user.telegram_id}\n'
        f'Til: {user.preferred_language}\n'
        f'Sevimlilar: {favorite_count}\n'
        f'VIP: {vip_status}',
        parse_mode=None,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [premium_button("VIP haqida", "profile", "vip_info", style="success")],
            [premium_button("Asosiy menyu", "brand", "main_menu")],
        ]),
    )
    await callback.answer()


@router.callback_query(F.data == "vip_info")
async def vip_info_callback(callback: CallbackQuery) -> None:
    session_factory = get_session_factory()
    async with session_factory() as session:
        vip_service = VipService(session)
        membership = await vip_service.get_membership(callback.from_user.id)
        plans = await vip_service.get_purchase_plans()

    active_membership = membership and membership.expires_at > datetime.now()
    status = (
        f"VIP faol, {membership.expires_at:%d.%m.%Y} gacha.\n\n"
        if active_membership
        else "VIP hozircha faol emas.\n\n"
    )
    await _edit_callback_message(
        callback,
        "💎 VIP obuna\n\n"
        f"{status}"
        "Muddat va narx:\n"
        + "\n".join(
            f"• {plan.title} — {plan.stars} ⭐"
            + (
                f" ({plan.discount_percent}% chegirma, avval "
                f"{VIP_PLANS[plan.key].stars} ⭐)"
                if plan.discount_percent
                else ""
            )
            for plan in plans
        )
        + "\n\n"
        "To‘lov Telegram Stars orqali amalga oshadi. To‘lov tasdiqlangach "
        "VIP muddati tanlangan davrga o‘rnatiladi. Reklamasiz imkoniyat "
        "reklama botga qo‘shilgach amal qiladi.",
        parse_mode=None,
        reply_markup=build_vip_purchase_keyboard(plans),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("vip_buy:"))
async def vip_purchase_callback(callback: CallbackQuery) -> None:
    _, plan_key = callback.data.split(":", maxsplit=1)
    session_factory = get_session_factory()
    async with session_factory() as session:
        plan = await VipService(session).get_purchase_plan(plan_key)
    if plan is None:
        await callback.answer("VIP tarifi topilmadi.", show_alert=True)
        return

    await callback.answer()
    try:
        await callback.bot.send_invoice(
            chat_id=callback.from_user.id,
            title=f"Anime TV VIP — {plan.title}",
            description=f"Anime TV VIP obunasi: {plan.title} ({plan.days} kun).",
            payload=(
                f"vip:{plan.key}:{callback.from_user.id}:"
                f"{plan.discount_percent}"
            ),
            currency="XTR",
            prices=[
                LabeledPrice(
                    label=f"VIP {plan.title}",
                    amount=plan.stars,
                )
            ],
            provider_token="",
            start_parameter=f"vip-{plan.key}",
        )
    except TelegramAPIError:
        logging.getLogger(__name__).exception("VIP Stars invoice creation failed")
        await callback.bot.send_message(
            callback.from_user.id,
            "To‘lov oynasini ochib bo‘lmadi. Birozdan keyin qayta urinib ko‘ring.",
        )


@router.pre_checkout_query()
async def vip_pre_checkout_handler(query: PreCheckoutQuery) -> None:
    plan = parse_vip_invoice_payload(
        query.invoice_payload,
        telegram_id=query.from_user.id,
        currency=query.currency,
        total_amount=query.total_amount,
    )
    if plan is None:
        await query.answer(
            ok=False,
            error_message="To‘lov ma’lumotlari noto‘g‘ri. VIP menyusidan qayta urinib ko‘ring.",
        )
        return
    await query.answer(ok=True)


@router.message(F.successful_payment)
async def vip_successful_payment_handler(
    message: Message,
) -> None:
    payment: SuccessfulPayment | None = message.successful_payment
    if payment is None or message.from_user is None:
        return

    plan = parse_vip_invoice_payload(
        payment.invoice_payload,
        telegram_id=message.from_user.id,
        currency=payment.currency,
        total_amount=payment.total_amount,
    )
    if plan is None:
        logging.getLogger(__name__).error(
            "Received invalid VIP Stars payment payload for user %s",
            message.from_user.id,
        )
        await message.answer(
            "To‘lov qabul qilindi, lekin VIP ma’lumotini tekshirishda muammo yuz berdi. "
            "Administratorga murojaat qiling."
        )
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        user = await UserService(session).get_or_create_user(
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
        )
        membership, activated = await VipService(session).activate_paid_membership(
            user.telegram_id,
            plan=plan,
            currency=payment.currency,
            total_amount=payment.total_amount,
            telegram_charge_id=payment.telegram_payment_charge_id,
        )

    if membership is None:
        logging.getLogger(__name__).error(
            "Could not activate VIP membership for paid user %s",
            message.from_user.id,
        )
        await message.answer(
            "To‘lov qabul qilindi, lekin VIP yoqilmadi. Administratorga murojaat qiling."
        )
        return

    if not activated:
        await message.answer(
            f"Bu to‘lov oldin qayta ishlangan. VIP muddati: "
            f"{membership.expires_at:%d.%m.%Y %H:%M} gacha."
        )
        return

    await message.answer(
        f"To‘lov muvaffaqiyatli! 💎\n"
        f"VIP {plan.title} uchun faollashtirildi.\n"
        f"Amal qilish muddati: {membership.expires_at:%d.%m.%Y %H:%M} gacha.",
        parse_mode=None,
    )


@router.callback_query(F.data == "language")
async def language_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    await state.clear()
    session_factory = get_session_factory()
    async with session_factory() as session:
        language = await UserService(session).get_preferred_language(
            callback.from_user.id
        )
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🇺🇿 O‘zbekcha",
            callback_data="language_uz",
            style="success",
        )],
        [InlineKeyboardButton(
            text="🇷🇺 Русский",
            callback_data="language_ru",
        )],
        [InlineKeyboardButton(
            text="🇬🇧 English",
            callback_data="language_en",
        )],
        [InlineKeyboardButton(
            text=get_text("language_back", language),
            callback_data="main_menu",
        )],
    ])
    await _edit_callback_message(
        callback,
        get_text("language_prompt", language),
        parse_mode=None,
        reply_markup=keyboard,
    )
    await callback.answer()


@router.callback_query(
    F.data.in_({f"language_{language}" for language in SUPPORTED_LANGUAGES})
)
async def language_selection_callback(callback: CallbackQuery) -> None:
    language = callback.data.removeprefix("language_")
    if language not in SUPPORTED_LANGUAGES:
        await callback.answer("Til tanlovi noto‘g‘ri.", show_alert=True)
        return
    session_factory = get_session_factory()
    async with session_factory() as session:
        user_service = UserService(session)
        user = await user_service.get_user_by_telegram_id(callback.from_user.id)
        if user is None:
            await user_service.get_or_create_user(
                telegram_id=callback.from_user.id,
                username=callback.from_user.username,
                first_name=callback.from_user.first_name,
                preferred_language=language,
            )
        else:
            await user_service.set_language(user, language)

    await _edit_callback_message(
        callback,
        get_text("language_changed", language),
        reply_markup=build_main_menu(language=language),
    )
    await callback.answer()


@router.callback_query(F.data == "main_menu")
async def main_menu_callback(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    await state.clear()
    session_factory = get_session_factory()
    async with session_factory() as session:
        language = await UserService(session).get_preferred_language(
            callback.from_user.id
        )
    await _edit_callback_message(
        callback,
        get_text("menu_callback", language),
        parse_mode=None,
        reply_markup=build_main_menu(language=language),
    )
    await callback.answer()


@router.callback_query(F.data == "about")
async def about_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    session_factory = get_session_factory()
    async with session_factory() as session:
        language = await UserService(session).get_preferred_language(
            callback.from_user.id
        )
    await _edit_callback_message(
        callback,
        "🎀 Anime TV\n\nAnime katalogini ko‘ring, qidiring va sevimlilaringizni saqlang.",
        parse_mode=None,
        reply_markup=build_main_menu(language=language),
    )
    await callback.answer()
