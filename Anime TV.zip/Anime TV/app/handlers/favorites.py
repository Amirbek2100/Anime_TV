from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.keyboards.anime import PAGE_SIZE, build_anime_list_keyboard
from app.keyboards.main_menu import build_main_menu
from app.database.session import get_session_factory
from app.services.anime_service import AnimeService

router = Router()


@router.message(Command('favorites'))
async def favorites_command(message: Message) -> None:
    if not message.from_user:
        await message.answer('Foydalanuvchi ma\'lumoti topilmadi.')
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        service = AnimeService(session)
        results, total = await service.get_favorites(
            message.from_user.id,
            limit=PAGE_SIZE,
            offset=0,
        )

    if total == 0:
        await message.answer(
            '❤️ Sevimlilar ro\'yxati hozircha bo\'sh.',
            reply_markup=build_main_menu(),
        )
        return

    lines = ['❤️ Sevimlilarim']
    for index, anime in enumerate(results, start=1):
        lines.append(f'{index}. {anime.title}')
    await message.answer(
        '\n'.join(lines),
        parse_mode=None,
        reply_markup=build_anime_list_keyboard(
            results,
            section='favorites',
            total=total,
        ),
    )
