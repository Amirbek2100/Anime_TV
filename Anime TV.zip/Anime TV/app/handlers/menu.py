from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app.keyboards.main_menu import build_main_menu
from app.database.session import get_session_factory
from app.services.user_service import UserService
from app.utils.localization import get_text
from app.utils.premium_emojis import build_premium_text

router = Router()


@router.message(Command('menu'))
@router.message(Command('help'))
async def menu_command(message: Message, state: FSMContext) -> None:
    await state.clear()
    language = "uz"
    if message.from_user:
        session_factory = get_session_factory()
        async with session_factory() as session:
            language = await UserService(session).get_preferred_language(
                message.from_user.id
            )
    menu_text, menu_entities = build_premium_text([
        ("brand", "🎀"),
        (None, get_text("menu_title", language)),
        ("catalog", "🏆"),
        (None, get_text("menu_prompt", language)),
    ])
    await message.answer(
        menu_text,
        entities=menu_entities,
        parse_mode=None,
        reply_markup=build_main_menu(language=language),
    )
