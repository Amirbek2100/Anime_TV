from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command('ban'))
async def ban_command(message: Message) -> None:
    await message.answer('🧐 Moderatsiya buyrug\'i bajarildi.')
