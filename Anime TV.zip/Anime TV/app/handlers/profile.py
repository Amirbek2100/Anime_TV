from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.keyboards.main_menu import build_main_menu
from app.database.session import get_session_factory
from app.services.anime_service import AnimeService
from app.services.user_service import UserService

router = Router()


@router.message(Command('profile'))
async def profile_command(message: Message) -> None:
    if not message.from_user:
        await message.answer('Foydalanuvchi ma\'lumoti topilmadi.')
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        user_service = UserService(session)
        anime_service = AnimeService(session)
        user = await user_service.get_user_by_telegram_id(message.from_user.id)
        favorite_count = await anime_service.get_favorite_count(user.id) if user else 0

    if user is None:
        await message.answer(
            'Profil topilmadi. /start orqali qayta ro\'yxatdan o\'ting.',
            reply_markup=build_main_menu(),
        )
        return

    await message.answer(
        f'✏️ PROFILIM\n\n😎 Telegram ID: {user.telegram_id}\n🌐 Til: {user.preferred_language}\n❤️ Sevimlilar: {favorite_count}',
        reply_markup=build_main_menu(),
    )
