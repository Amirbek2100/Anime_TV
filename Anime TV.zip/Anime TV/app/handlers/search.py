from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app.database.session import get_session_factory
from app.keyboards.anime import build_anime_selection_keyboard
from app.keyboards.main_menu import build_main_menu
from app.services.anime_service import AnimeService
from app.states.search_states import AnimeSearchState

router = Router()


async def send_search_results(message: Message, query: str) -> None:
    session_factory = get_session_factory()
    async with session_factory() as session:
        service = AnimeService(session)
        results, total = await service.search(query, limit=5)

    if total == 0:
        await message.answer(
            f'🔍 "{query}" bo‘yicha anime topilmadi.',
            reply_markup=build_main_menu(),
        )
        return

    lines = [f'🔍 "{query}" bo‘yicha natijalar ({total} ta):', '']
    lines.extend(
        f'{index}. {anime.title}'
        for index, anime in enumerate(results, start=1)
    )
    await message.answer(
        '\n'.join(lines),
        parse_mode=None,
        reply_markup=build_anime_selection_keyboard(results),
    )


@router.message(Command('search'))
async def search_command(message: Message, state: FSMContext) -> None:
    text = message.text or ''
    parts = text.split(maxsplit=1)
    query = parts[1].strip() if len(parts) > 1 else ''
    if not query:
        await state.set_state(AnimeSearchState.waiting_query)
        await message.answer('🔍 Anime nomini yuboring yoki qidiruvni bekor qilish uchun /menu bosing.')
        return

    await state.clear()
    await send_search_results(message, query)


@router.message(AnimeSearchState.waiting_query)
async def search_query_handler(message: Message, state: FSMContext) -> None:
    query = (message.text or '').strip()
    if not query:
        await message.answer('🔍 Anime nomini matn ko‘rinishida yuboring.')
        return

    await state.clear()
    await send_search_results(message, query)
