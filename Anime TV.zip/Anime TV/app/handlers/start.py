from __future__ import annotations

import logging
from pathlib import Path

from aiogram import Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import FSInputFile, Message

from app.database.session import get_session_factory
from app.services.user_service import UserService
from app.keyboards.main_menu import build_main_menu
from app.utils.localization import get_text, get_welcome_parts
from app.utils.premium_emojis import build_premium_text

router = Router()
logger = logging.getLogger(__name__)
WELCOME_BANNER = Path(__file__).resolve().parents[1] / "assets" / "welcome-banner.jpg"


@router.message(Command('start'))
async def start_command(message: Message, state: FSMContext) -> None:
    await state.clear()
    if not message.from_user:
        await message.answer('Foydalanuvchi ma\'lumoti topilmadi.')
        return

    session_factory = get_session_factory()
    async with session_factory() as session:
        service = UserService(session)
        user = await service.get_or_create_user(
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
        )

    language = user.preferred_language
    welcome_text, welcome_entities = build_premium_text(get_welcome_parts(language))
    try:
        await message.answer_photo(
            photo=FSInputFile(WELCOME_BANNER),
            caption=welcome_text,
            caption_entities=welcome_entities,
            parse_mode=None,
            reply_markup=build_main_menu(language=language),
        )
    except TelegramBadRequest as exc:
        error_text = str(exc).casefold()
        if not any(term in error_text for term in ("emoji", "icon_custom_emoji_id", "button_type_invalid")):
            raise

        logger.warning(
            "Telegram rejected premium emoji markup for /start; retrying with a basic menu: %s",
            exc,
        )
        await message.answer_photo(
            photo=FSInputFile(WELCOME_BANNER),
            caption=get_text("welcome_fallback", language),
            reply_markup=build_main_menu(
                language=language,
                premium_icons=False,
            ),
        )
