from __future__ import annotations

from collections.abc import Sequence

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.database.models import Anime, AnimeEpisode, AnimeSeason
from app.utils.premium_emojis import ButtonStyle, PREMIUM_EMOJIS, premium_button

PAGE_SIZE = 8
_ITEM_BUTTON_STYLES: tuple[ButtonStyle, ...] = ("primary", "success", "danger")

_CATEGORY_BUTTONS = (
    ("catalog", "Anime katalogi", "catalog", "danger"),
    ("popular", "Mashhur", "popular", "primary"),
    ("recent", "Yangi", "recent", "danger"),
    ("favorites", "Sevimlilar", "favorites", "primary"),
)


def _build_category_navigation(section: str) -> list[list[InlineKeyboardButton]]:
    buttons = [
        premium_button(
            label,
            emoji_name,
            callback_data,
            style="success" if section == callback_data else style,
        )
        for callback_data, label, emoji_name, style in _CATEGORY_BUTTONS
    ]
    return [buttons[:2], buttons[2:]]


def build_anime_selection_keyboard(
    anime_list: Sequence[Anime],
    *,
    section: str = "catalog",
) -> InlineKeyboardMarkup:
    rows = []
    rows.extend([
        [
            premium_button(
                anime.title[:40],
                "catalog",
                f"anime:{anime.id}:{section}:0",
                style=_ITEM_BUTTON_STYLES[index % len(_ITEM_BUTTON_STYLES)],
            )
        ]
        for index, anime in enumerate(anime_list)
    ])
    rows.extend(_build_category_navigation(section))
    rows.append([premium_button("Asosiy menyu", "brand", "main_menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_anime_list_keyboard(
    anime_list: Sequence[Anime],
    *,
    section: str,
    offset: int = 0,
    total: int | None = None,
) -> InlineKeyboardMarkup:
    rows = []
    rows.extend([
        [
            premium_button(
                anime.title[:40],
                "catalog",
                f"anime:{anime.id}:{section}:{offset}",
                style=_ITEM_BUTTON_STYLES[index % len(_ITEM_BUTTON_STYLES)],
            )
        ]
        for index, anime in enumerate(anime_list)
    ])
    navigation = []
    if offset > 0:
        navigation.append(
            premium_button(
                "Oldingi",
                "recent",
                f"list:{section}:{max(0, offset - PAGE_SIZE)}",
                style="danger",
            )
        )
    if total is not None and offset + len(anime_list) < total:
        navigation.append(
            premium_button(
                "Keyingi",
                "recent",
                f"list:{section}:{offset + PAGE_SIZE}",
                style="success",
            )
        )
    if navigation:
        rows.append(navigation)
    rows.append([premium_button("Asosiy menyu", "brand", "main_menu")])
    rows.extend(_build_category_navigation(section))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_anime_detail_keyboard(
    anime_id: int,
    *,
    section: str,
    is_favorite: bool,
    return_offset: int = 0,
    favorite_list: bool = False,
    season_count: int = 0,
) -> InlineKeyboardMarkup:
    favorite_text = "Sevimlidan olib tashlash" if is_favorite else "Sevimlilarga qo‘shish"
    favorite_action = "remove_favorite" if is_favorite else "add_favorite"
    rows = []
    if season_count:
        rows.append([
            premium_button(
                f"Fasllar ({season_count})",
                "recent",
                f"seasons:{anime_id}:{section}:{return_offset}",
                style="success",
            )
        ])
    rows.append([
        premium_button(
            favorite_text,
            "favorites",
            f"{favorite_action}:{anime_id}:{section}:{return_offset}",
            style="success" if not is_favorite else "danger",
        )
    ])
    if favorite_list:
        rows.append([
            premium_button(
                "Sevimlilarga qaytish",
                "favorites",
                "favorites",
                style="success",
            )
        ])
    else:
        rows.append([
            premium_button(
                "Ro‘yxatga qaytish",
                "recent",
                f"list:{section}:{return_offset}",
            )
        ])
    rows.append([premium_button("Asosiy menyu", "brand", "main_menu")])
    rows.extend(_build_category_navigation(section))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_season_list_keyboard(
    seasons: Sequence[AnimeSeason],
    *,
    anime_id: int,
    section: str,
    return_offset: int,
) -> InlineKeyboardMarkup:
    rows = []
    rows.extend([
        [
            premium_button(
                f"{season.title} ({len(season.episodes)} qism)",
                "recent",
                f"season:{season.id}:{anime_id}:{section}:{return_offset}:0",
                style=_ITEM_BUTTON_STYLES[index % len(_ITEM_BUTTON_STYLES)],
            )
        ]
        for index, season in enumerate(seasons)
    ])
    rows.append([
        premium_button(
            "Animega qaytish",
            "catalog",
            f"anime:{anime_id}:{section}:{return_offset}",
        )
    ])
    rows.extend(_build_category_navigation(section))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_episode_list_keyboard(
    episodes: Sequence[AnimeEpisode],
    *,
    offset: int = 0,
    anime_id: int,
    season_id: int,
    section: str,
    return_offset: int,
) -> InlineKeyboardMarkup:
    page = episodes[offset:offset + PAGE_SIZE]
    rows = []
    rows.extend([
        [
            InlineKeyboardButton(
                text=(
                    f"{episode.number}-qism"
                    + (f": {episode.title[:28]}" if episode.title else "")
                ),
                icon_custom_emoji_id=PREMIUM_EMOJIS["recent"],
                style=_ITEM_BUTTON_STYLES[index % len(_ITEM_BUTTON_STYLES)],
                url=episode.watch_url,
            )
        ]
        for index, episode in enumerate(page)
    ])
    navigation = []
    if offset > 0:
        navigation.append(
            premium_button(
                "Oldingi qismlar",
                "recent",
                f"season:{season_id}:{anime_id}:{section}:{return_offset}:"
                f"{max(0, offset - PAGE_SIZE)}",
                style="danger",
            )
        )
    if offset + len(page) < len(episodes):
        navigation.append(
            premium_button(
                "Keyingi qismlar",
                "recent",
                f"season:{season_id}:{anime_id}:{section}:{return_offset}:"
                f"{offset + PAGE_SIZE}",
                style="success",
            )
        )
    if navigation:
        rows.append(navigation)
    rows.append([
        premium_button(
            "Fasllarga qaytish",
            "catalog",
            f"seasons:{anime_id}:{section}:{return_offset}",
        )
    ])
    rows.extend(_build_category_navigation(section))
    return InlineKeyboardMarkup(inline_keyboard=rows)
