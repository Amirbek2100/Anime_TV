from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.utils.localization import get_text, normalize_language
from app.utils.premium_emojis import ButtonStyle, premium_button


def build_main_menu(
    *,
    language: str = "uz",
    premium_icons: bool = True,
) -> InlineKeyboardMarkup:
    language = normalize_language(language)

    def button(
        text: str,
        emoji_name: str,
        callback_data: str,
        *,
        style: ButtonStyle | None = "primary",
    ) -> InlineKeyboardButton:
        if premium_icons:
            return premium_button(text, emoji_name, callback_data, style=style)
        return InlineKeyboardButton(text=text, callback_data=callback_data, style=style)

    return InlineKeyboardMarkup(inline_keyboard=[
        [
            button(get_text("catalog", language), "catalog", "catalog", style="danger"),
            button(get_text("search", language), "search", "search", style="primary"),
        ],
        [
            button(get_text("popular", language), "popular", "popular", style="success"),
            button(get_text("recent", language), "recent", "recent", style="primary"),
        ],
        [
            button(get_text("favorites", language), "favorites", "favorites", style="danger"),
            button(get_text("profile", language), "profile", "profile", style="success"),
        ],
        [
            button(get_text("language", language), "language", "language", style="primary"),
            button(get_text("vip", language), "favorites", "vip_info", style="danger"),
        ],
    ])
