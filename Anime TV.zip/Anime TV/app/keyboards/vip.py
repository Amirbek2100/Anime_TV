from aiogram.types import InlineKeyboardMarkup

from app.services.vip_service import VIP_PLANS, VipPlan
from app.utils.premium_emojis import premium_button


def build_vip_purchase_keyboard(
    plans: list[VipPlan] | None = None,
) -> InlineKeyboardMarkup:
    plans = plans or list(VIP_PLANS.values())
    rows = [
        [
            premium_button(
                f"{plan.title} — {plan.stars} ⭐"
                + (
                    f" (-{plan.discount_percent}%)"
                    if plan.discount_percent
                    else ""
                ),
                "favorites",
                f"vip_buy:{plan.key}",
                style="success",
            )
        ]
        for plan in plans
    ]
    rows.extend([
        [premium_button("Profilga qaytish", "profile", "profile")],
        [premium_button("Asosiy menyu", "brand", "main_menu")],
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)
