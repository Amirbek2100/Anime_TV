from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramAPIError
from aiogram.types import (
    BotCommand,
    BotCommandScopeAllGroupChats,
    BotCommandScopeAllPrivateChats,
    BotCommandScopeChat,
    BotCommandScopeChatMember,
    BotCommandScopeDefault,
)

from app.config import get_settings
from app.database.session import init_db
from app.utils.premium_emojis import PremiumEmojiMiddleware
from app.handlers import (
    admin_router,
    anime_router,
    announcements_router,
    callbacks_router,
    favorites_router,
    menu_router,
    moderation_router,
    profile_router,
    search_router,
    start_router,
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
logger = logging.getLogger(__name__)

USER_COMMANDS = [
    BotCommand(command="start", description="Botni ishga tushirish"),
    BotCommand(command="menu", description="Asosiy menyuni ochish"),
    BotCommand(command="help", description="Yordam va menyu"),
    BotCommand(command="anime", description="Anime katalogini ko‘rish"),
    BotCommand(command="search", description="Anime qidirish"),
    BotCommand(command="favorites", description="Sevimli animelar"),
    BotCommand(command="profile", description="Profilimni ko‘rish"),
    BotCommand(command="language", description="Tilni o‘zgartirish"),
    BotCommand(command="about", description="Bot haqida"),
    BotCommand(command="id", description="Telegram ID raqamim"),
]

ADMIN_COMMANDS = [
    *USER_COMMANDS,
    BotCommand(command="admin", description="Admin panelini ochish"),
    BotCommand(command="stats", description="Bot statistikasini ko‘rish"),
    BotCommand(command="add_anime", description="Anime qo‘shish"),
    BotCommand(command="edit_anime", description="Animeni tahrirlash"),
    BotCommand(command="delete_anime", description="Animeni o‘chirish"),
    BotCommand(command="announce", description="E’lon yuborish"),
    BotCommand(command="backup", description="Ma’lumotlar zaxira nusxasi"),
    BotCommand(command="cancel", description="Joriy amalni bekor qilish"),
]


async def register_bot_commands(
    bot: Bot,
    admin_ids: list[int],
    group_id: int | None = None,
) -> None:
    await bot.set_my_commands(
        USER_COMMANDS,
        scope=BotCommandScopeDefault(),
    )
    await bot.set_my_commands(
        USER_COMMANDS,
        scope=BotCommandScopeAllPrivateChats(),
    )
    await bot.set_my_commands(
        USER_COMMANDS,
        scope=BotCommandScopeAllGroupChats(),
    )

    positive_admin_ids = sorted({admin_id for admin_id in admin_ids if admin_id > 0})
    for admin_id in positive_admin_ids:
        await bot.set_my_commands(
            ADMIN_COMMANDS,
            scope=BotCommandScopeChat(chat_id=admin_id),
        )
        if group_id is not None:
            try:
                await bot.set_my_commands(
                    ADMIN_COMMANDS,
                    scope=BotCommandScopeChatMember(
                        chat_id=group_id,
                        user_id=admin_id,
                    ),
                )
            except TelegramAPIError as exc:
                logger.warning(
                    "Could not register admin command menu in GROUP_ID; "
                    "admin private-chat commands remain enabled: %s",
                    exc,
                )


async def on_startup(bot: Bot) -> None:
    await init_db()
    settings = get_settings()
    await register_bot_commands(bot, settings.admin_ids, settings.group_id)
    await bot.set_my_description(
        description=(
            "Anime TV — animelarni katalogdan toping, nomi bo'yicha qidiring "
            "va sevimlilaringizni saqlang. /start tugmasini bosib boshlang."
        )
    )
    await bot.set_my_short_description(
        short_description="Anime katalogi, qidiruv va sevimlilar"
    )
    logging.info('Anime TV bot started. Token configured: %s', bool(get_settings().bot_token))


async def main() -> None:
    settings = get_settings()
    bot = Bot(token=settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    bot.session.middleware.register(PremiumEmojiMiddleware())
    dp = Dispatcher()

    dp.include_routers(
        start_router,
        menu_router,
        anime_router,
        search_router,
        favorites_router,
        profile_router,
        announcements_router,
        admin_router,
        moderation_router,
        callbacks_router,
    )

    dp.startup.register(on_startup)
    await dp.start_polling(bot)


if __name__ == '__main__':
    asyncio.run(main())
