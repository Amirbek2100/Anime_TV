from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.database.models import Anime, Favorite, Genre, User, anime_genres


class AnimeService:
    def __init__(self, session):
        self.session = session

    async def create_anime(self, *, title: str, description: str | None, release_year: int | None, genres: Sequence[str] | None = None, poster_url: str | None = None, authorized_link: str | None = None, alternative_title: str | None = None, status: str | None = None, age_rating: str | None = None, source: str | None = None) -> Anime:
        anime = Anime(
            title=title.strip(),
            alternative_title=(alternative_title.strip() if alternative_title else None),
            description=description.strip() if description else None,
            poster_url=poster_url.strip() if poster_url else None,
            release_year=release_year,
            status=status,
            age_rating=age_rating,
            source=source,
            authorized_link=authorized_link.strip() if authorized_link else None,
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        self.session.add(anime)
        await self.session.flush()

        existing_genres = []
        for genre_name in genres or []:
            name = genre_name.strip()
            if not name:
                continue
            genre = await self.session.scalar(select(Genre).where(Genre.name == name))
            if genre is None:
                genre = Genre(name=name)
                self.session.add(genre)
                await self.session.flush()
            existing_genres.append(genre)

        if existing_genres:
            await self.session.execute(
                anime_genres.insert(),
                [{"anime_id": anime.id, "genre_id": genre.id} for genre in existing_genres],
            )
        await self.session.commit()
        await self.session.refresh(anime)
        return anime

    async def count_anime(self) -> int:
        total = await self.session.scalar(select(func.count()).select_from(Anime))
        return total or 0

    async def get_by_id(self, anime_id: int) -> Anime | None:
        stmt = select(Anime).options(selectinload(Anime.genres)).where(Anime.id == anime_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def update_anime(self, anime_id: int, **updates) -> Anime | None:
        anime = await self.get_by_id(anime_id)
        if anime is None:
            return None

        for field_name, value in updates.items():
            if field_name not in {"title", "alternative_title", "description", "poster_url", "release_year", "status", "age_rating", "source", "authorized_link"}:
                continue
            if value is None:
                if field_name != "title":
                    setattr(anime, field_name, None)
                continue
            if isinstance(value, str):
                clean_value = value.strip()
                if clean_value == "":
                    continue
                setattr(anime, field_name, clean_value)
            else:
                setattr(anime, field_name, value)

        anime.updated_at = datetime.now()
        await self.session.commit()
        await self.session.refresh(anime)
        return anime

    async def update_genres(
        self,
        anime_id: int,
        genres: Sequence[str],
    ) -> Anime | None:
        anime = await self.get_by_id(anime_id)
        if anime is None:
            return None

        updated_genres: list[Genre] = []
        seen_names: set[str] = set()
        for genre_name in genres:
            name = genre_name.strip()
            if not name or name.casefold() in seen_names:
                continue
            seen_names.add(name.casefold())
            genre = await self.session.scalar(
                select(Genre).where(func.lower(Genre.name) == name.casefold())
            )
            if genre is None:
                genre = Genre(name=name)
                self.session.add(genre)
                await self.session.flush()
            updated_genres.append(genre)

        anime.genres = updated_genres
        anime.updated_at = datetime.now()
        await self.session.commit()
        return await self.get_by_id(anime_id)

    async def delete_anime(self, anime_id: int) -> bool:
        anime = await self.get_by_id(anime_id)
        if anime is None:
            return False
        await self.session.delete(anime)
        await self.session.commit()
        return True

    async def search(self, query: str, limit: int = 10, offset: int = 0):
        text = query.strip()
        if not text:
            return [], 0
        pattern = f"%{text}%"
        stmt = select(Anime).options(selectinload(Anime.genres)).where(Anime.title.ilike(pattern)).order_by(Anime.title.asc()).limit(limit).offset(offset)
        total_stmt = select(func.count()).select_from(Anime).where(Anime.title.ilike(pattern))
        results = await self.session.execute(stmt)
        total = await self.session.scalar(total_stmt)
        return list(results.scalars().all()), total or 0

    async def list_recent(self, limit: int = 10, offset: int = 0):
        stmt = (
            select(Anime)
            .options(selectinload(Anime.genres))
            .order_by(Anime.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def get_popular(self, limit: int = 10, offset: int = 0):
        stmt = (
            select(Anime)
            .options(selectinload(Anime.genres))
            .outerjoin(Favorite, Favorite.anime_id == Anime.id)
            .group_by(Anime.id)
            .order_by(func.count(Favorite.id).desc(), Anime.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def get_favorite_count(self, user_id: int) -> int:
        stmt = select(func.count()).select_from(Favorite).where(Favorite.user_id == user_id)
        return await self.session.scalar(stmt) or 0

    async def get_all(self, limit: int = 20, offset: int = 0):
        stmt = select(Anime).options(selectinload(Anime.genres)).order_by(Anime.title.asc()).limit(limit).offset(offset)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def add_favorite(self, telegram_user_id: int, anime_id: int) -> Favorite:
        user = await self.session.scalar(select(User).where(User.telegram_id == telegram_user_id))
        if user is None:
            raise ValueError("User not found")
        existing = await self.session.scalar(select(Favorite).where(Favorite.user_id == user.id, Favorite.anime_id == anime_id))
        if existing is not None:
            return existing
        favorite = Favorite(user_id=user.id, anime_id=anime_id)
        self.session.add(favorite)
        await self.session.commit()
        await self.session.refresh(favorite)
        return favorite

    async def is_favorite(self, telegram_user_id: int, anime_id: int) -> bool:
        favorite = await self.session.scalar(
            select(Favorite)
            .join(User, Favorite.user_id == User.id)
            .where(
                User.telegram_id == telegram_user_id,
                Favorite.anime_id == anime_id,
            )
        )
        return favorite is not None

    async def remove_favorite(self, telegram_user_id: int, anime_id: int) -> bool:
        user = await self.session.scalar(select(User).where(User.telegram_id == telegram_user_id))
        if user is None:
            return False
        favorite = await self.session.scalar(select(Favorite).where(Favorite.user_id == user.id, Favorite.anime_id == anime_id))
        if favorite is None:
            return False
        await self.session.delete(favorite)
        await self.session.commit()
        return True

    async def get_favorites(self, telegram_user_id: int, limit: int = 10, offset: int = 0):
        user = await self.session.scalar(select(User).where(User.telegram_id == telegram_user_id))
        if user is None:
            return [], 0
        stmt = (
            select(Anime)
            .join(Favorite, Favorite.anime_id == Anime.id)
            .where(Favorite.user_id == user.id)
            .options(selectinload(Anime.genres))
            .order_by(Anime.title.asc())
            .limit(limit)
            .offset(offset)
        )
        total_stmt = select(func.count()).select_from(Favorite).where(Favorite.user_id == user.id)
        results = await self.session.execute(stmt)
        total = await self.session.scalar(total_stmt)
        return list(results.scalars().all()), total or 0
