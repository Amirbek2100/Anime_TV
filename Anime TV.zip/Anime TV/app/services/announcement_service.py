from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import Announcement, User


class AnnouncementService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create_announcement(self, *, message: str, created_by: int | None = None) -> Announcement:
        announcement = Announcement(message=message.strip(), created_by=created_by, created_at=datetime.now())
        self.session.add(announcement)
        await self.session.commit()
        await self.session.refresh(announcement)
        return announcement

    async def count_announcements(self) -> int:
        result = await self.session.execute(select(Announcement))
        return len(result.scalars().all())

    async def get_admin_user(self, telegram_id: int) -> User | None:
        return await self.session.scalar(select(User).where(User.telegram_id == telegram_id))
