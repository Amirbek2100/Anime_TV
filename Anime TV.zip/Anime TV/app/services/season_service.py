from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.database.models import Anime, AnimeEpisode, AnimeSeason


class SeasonService:
    def __init__(self, session):
        self.session = session

    async def create_season(
        self,
        *,
        anime_id: int,
        number: int,
        title: str,
        episodes: Sequence[tuple[int, str | None, str]],
    ) -> AnimeSeason | None:
        anime = await self.session.get(Anime, anime_id)
        if anime is None:
            return None

        season = AnimeSeason(
            anime_id=anime_id,
            number=number,
            title=title.strip(),
        )
        season.episodes = [
            AnimeEpisode(
                number=episode_number,
                title=episode_title.strip() if episode_title else None,
                watch_url=watch_url.strip(),
            )
            for episode_number, episode_title, watch_url in sorted(
                episodes,
                key=lambda episode: episode[0],
            )
        ]
        self.session.add(season)
        await self.session.commit()
        return await self.get_season(season.id)

    async def list_seasons(self, anime_id: int) -> list[AnimeSeason]:
        result = await self.session.scalars(
            select(AnimeSeason)
            .options(selectinload(AnimeSeason.episodes))
            .where(AnimeSeason.anime_id == anime_id)
            .order_by(AnimeSeason.number)
        )
        return list(result.all())

    async def get_season_by_number(
        self,
        anime_id: int,
        number: int,
    ) -> AnimeSeason | None:
        return await self.session.scalar(
            select(AnimeSeason).where(
                AnimeSeason.anime_id == anime_id,
                AnimeSeason.number == number,
            )
        )

    async def get_season(self, season_id: int) -> AnimeSeason | None:
        return await self.session.scalar(
            select(AnimeSeason)
            .options(selectinload(AnimeSeason.episodes))
            .where(AnimeSeason.id == season_id)
        )
