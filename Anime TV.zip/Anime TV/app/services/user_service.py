from __future__ import annotations

from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import User


class UserService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_or_create_user(
        self,
        telegram_id: int,
        username: str | None = None,
        first_name: str | None = None,
        preferred_language: str | None = None,
    ) -> User:
        stmt = select(User).where(User.telegram_id == telegram_id)
        result = await self.session.execute(stmt)
        user = result.scalar_one_or_none()
        if user is not None:
            user.username = username or user.username
            user.first_name = first_name or user.first_name
            user.preferred_language = preferred_language or user.preferred_language
            user.last_activity_at = datetime.now()
            await self.session.commit()
            return user

        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            preferred_language=preferred_language or "uz",
            last_activity_at=datetime.now(),
        )
        self.session.add(user)
        await self.session.commit()
        await self.session.refresh(user)
        return user

    async def count_users(self) -> int:
        total = await self.session.scalar(select(func.count()).select_from(User))
        return total or 0

    async def get_notification_recipients(self) -> list[int]:
        result = await self.session.scalars(
            select(User.telegram_id).where(
                User.is_active.is_(True),
                User.notification_preference == "enabled",
            )
        )
        return list(result.all())

    async def get_user_by_telegram_id(self, telegram_id: int) -> User | None:
        stmt = select(User).where(User.telegram_id == telegram_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_preferred_language(self, telegram_id: int) -> str:
        user = await self.get_user_by_telegram_id(telegram_id)
        return user.preferred_language if user is not None else "uz"

    async def set_language(self, user: User, language: str) -> User:
        user.preferred_language = language
        user.last_activity_at = datetime.now()
        await self.session.commit()
        return user
