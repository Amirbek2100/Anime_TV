from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timedelta

from sqlalchemy import func, select

from app.database.models import BotSetting, User, VipMembership, VipPayment


@dataclass(frozen=True)
class VipPlan:
    key: str
    title: str
    days: int
    stars: int
    discount_percent: int = 0


VIP_PLANS = {
    "month": VipPlan("month", "1 oy", 30, 56),
    "three_months": VipPlan("three_months", "3 oy", 90, 132),
    "six_months": VipPlan("six_months", "6 oy", 180, 226),
    "year": VipPlan("year", "1 yil", 365, 454),
}


def parse_vip_invoice_payload(
    payload: str,
    *,
    telegram_id: int,
    currency: str,
    total_amount: int,
) -> VipPlan | None:
    parts = payload.split(":")
    if (
        len(parts) not in {3, 4}
        or parts[0] != "vip"
        or not parts[2].isdecimal()
        or (
            len(parts) == 4
            and (not parts[3].isdecimal() or len(parts[3]) > 2)
        )
    ):
        return None
    plan = VIP_PLANS.get(parts[1])
    discount_percent = int(parts[3]) if len(parts) == 4 else 0
    try:
        expected_stars = (
            calculate_discounted_stars(plan.stars, discount_percent)
            if plan is not None
            else None
        )
    except ValueError:
        return None
    if (
        plan is None
        or parts[2] != str(telegram_id)
        or currency != "XTR"
        or total_amount != expected_stars
    ):
        return None
    return replace(plan, stars=expected_stars, discount_percent=discount_percent)


def calculate_discounted_stars(stars: int, discount_percent: int) -> int:
    if stars < 1:
        raise ValueError("Stars narxi kamida 1 bo‘lishi kerak.")
    if not 0 <= discount_percent <= 99:
        raise ValueError("Chegirma 0 dan 99 foizgacha bo‘lishi kerak.")
    return max(1, (stars * (100 - discount_percent) + 50) // 100)


class VipService:
    def __init__(self, session):
        self.session = session

    async def get_discount_percent(self, plan_key: str) -> int:
        if plan_key not in VIP_PLANS:
            raise ValueError("VIP tarifi topilmadi.")
        setting = await self.session.scalar(
            select(BotSetting).where(BotSetting.key == f"vip_discount_{plan_key}")
        )
        if setting is None or setting.value is None:
            return 0
        try:
            discount_percent = int(setting.value)
        except ValueError as exc:
            raise ValueError(f"{plan_key} VIP chegirma sozlamasi noto‘g‘ri.") from exc
        if not 0 <= discount_percent <= 99:
            raise ValueError(f"{plan_key} VIP chegirma sozlamasi noto‘g‘ri.")
        return discount_percent

    async def get_purchase_plan(self, plan_key: str) -> VipPlan | None:
        plan = VIP_PLANS.get(plan_key)
        if plan is None:
            return None
        discount_percent = await self.get_discount_percent(plan_key)
        return replace(
            plan,
            stars=calculate_discounted_stars(plan.stars, discount_percent),
            discount_percent=discount_percent,
        )

    async def get_purchase_plans(self) -> list[VipPlan]:
        plans = []
        for plan_key in VIP_PLANS:
            plan = await self.get_purchase_plan(plan_key)
            if plan is None:
                raise ValueError(f"{plan_key} VIP tarifi topilmadi.")
            plans.append(plan)
        return plans

    async def set_discount_percent(self, plan_key: str, discount_percent: int) -> None:
        if plan_key not in VIP_PLANS:
            raise ValueError("VIP tarifi topilmadi.")
        if not 0 <= discount_percent <= 99:
            raise ValueError("Chegirma 0 dan 99 foizgacha bo‘lishi kerak.")
        key = f"vip_discount_{plan_key}"
        setting = await self.session.scalar(
            select(BotSetting).where(BotSetting.key == key)
        )
        if setting is None:
            self.session.add(BotSetting(key=key, value=str(discount_percent)))
        else:
            setting.value = str(discount_percent)
        await self.session.commit()

    async def get_membership(
        self,
        telegram_id: int,
    ) -> VipMembership | None:
        return await self.session.scalar(
            select(VipMembership)
            .join(User, VipMembership.user_id == User.id)
            .where(User.telegram_id == telegram_id)
        )

    async def is_vip(self, telegram_id: int) -> bool:
        membership = await self.get_membership(telegram_id)
        return membership is not None and membership.expires_at > datetime.now()

    async def get_user_by_username(self, username: str) -> User | None:
        normalized = username.strip().removeprefix("@").casefold()
        if not normalized:
            return None
        return await self.session.scalar(
            select(User).where(func.lower(User.username) == normalized)
        )

    async def get_user_by_telegram_id(self, telegram_id: int) -> User | None:
        return await self.session.scalar(
            select(User).where(User.telegram_id == telegram_id)
        )

    async def grant_membership(
        self,
        telegram_id: int,
        *,
        days: int = 30,
    ) -> VipMembership | None:
        if days < 1:
            raise ValueError("VIP muddat kamida 1 kun bo‘lishi kerak.")

        user = await self.session.scalar(
            select(User).where(User.telegram_id == telegram_id)
        )
        if user is None:
            return None

        membership = await self.session.scalar(
            select(VipMembership).where(VipMembership.user_id == user.id)
        )
        now = datetime.now()
        start = (
            membership.expires_at
            if membership is not None and membership.expires_at > now
            else now
        )
        if membership is None:
            membership = VipMembership(
                user_id=user.id,
                expires_at=start + timedelta(days=days),
            )
            self.session.add(membership)
        else:
            membership.expires_at = start + timedelta(days=days)
            membership.updated_at = now

        await self.session.commit()
        await self.session.refresh(membership)
        return membership

    async def activate_paid_membership(
        self,
        telegram_id: int,
        *,
        plan: VipPlan,
        currency: str,
        total_amount: int,
        telegram_charge_id: str,
    ) -> tuple[VipMembership | None, bool]:
        if currency != "XTR" or total_amount != plan.stars:
            raise ValueError("VIP Stars to‘lovi tarif narxiga mos kelmaydi.")
        if not telegram_charge_id:
            raise ValueError("Telegram to‘lov identifikatori bo‘sh bo‘lishi mumkin emas.")

        existing_payment = await self.session.scalar(
            select(VipPayment).where(
                VipPayment.telegram_charge_id == telegram_charge_id
            )
        )
        if existing_payment is not None:
            owner_id = await self.session.scalar(
                select(User.telegram_id).where(User.id == existing_payment.user_id)
            )
            if owner_id != telegram_id:
                return None, False
            membership = await self.get_membership(telegram_id)
            return membership, False

        user = await self.session.scalar(
            select(User).where(User.telegram_id == telegram_id)
        )
        if user is None:
            return None, False

        membership = await self.session.scalar(
            select(VipMembership).where(VipMembership.user_id == user.id)
        )
        now = datetime.now()
        expires_at = now + timedelta(days=plan.days)
        if membership is None:
            membership = VipMembership(
                user_id=user.id,
                expires_at=expires_at,
                updated_at=now,
            )
            self.session.add(membership)
        else:
            membership.expires_at = expires_at
            membership.updated_at = now

        self.session.add(
            VipPayment(
                user_id=user.id,
                telegram_charge_id=telegram_charge_id,
                currency=currency,
                total_amount=total_amount,
                vip_days=plan.days,
            )
        )
        await self.session.commit()
        await self.session.refresh(membership)
        return membership, True
