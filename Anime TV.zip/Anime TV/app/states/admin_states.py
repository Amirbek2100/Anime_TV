from aiogram.fsm.state import State, StatesGroup


class AdminAnimeState(StatesGroup):
    waiting_details = State()
    waiting_title = State()
    waiting_description = State()
    waiting_year = State()
    waiting_genres = State()
    waiting_poster = State()
    waiting_link = State()
    preview = State()
    waiting_edit_id = State()
    waiting_edit_value = State()
    waiting_delete_id = State()
    delete_confirmation = State()
    waiting_announcement = State()
    announcement_preview = State()
    waiting_season_details = State()
    season_preview = State()
    waiting_vip_telegram_id = State()
    waiting_vip_days = State()
    waiting_vip_discount = State()
