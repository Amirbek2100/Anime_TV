from aiogram.fsm.state import State, StatesGroup


class AnimeSearchState(StatesGroup):
    waiting_query = State()
