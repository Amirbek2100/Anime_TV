from __future__ import annotations

SUPPORTED_LANGUAGES = ("uz", "ru", "en")

TRANSLATIONS = {
    "uz": {
        "welcome_title": " Anime TV ga xush kelibsiz!\n\n",
        "welcome_intro": " Anime olamiga sayohatingiz shu yerdan boshlanadi.\n\n",
        "welcome_search": " Anime qidiring\n",
        "welcome_popular": " Mashhur animelarni toping\n",
        "welcome_recent": " Yangi katalogni ko'ring\n",
        "welcome_favorites": " Sevimlilarni saqlang\n",
        "welcome_profile": " Profilingizni boshqaring\n",
        "welcome_community": " Hamjamiyatga qo'shiling\n\nKerakli bo'limni tanlang!",
        "welcome_fallback": (
            "Anime TV ga xush kelibsiz!\n\n"
            "Anime olamiga sayohatingiz shu yerdan boshlanadi.\n\n"
            "Anime qidiring\nMashhur animelarni toping\n"
            "Yangi katalogni ko'ring\nSevimlilarni saqlang\n"
            "Profilingizni boshqaring\n\nKerakli bo'limni tanlang!"
        ),
        "menu_title": "🎀 Anime TV menyusi\n\n",
        "menu_prompt": "🏆 Kerakli bo‘limni tanlang va anime olamiga kirish uchun davom eting.",
        "menu_callback": "🎀 Anime TV — asosiy menyu\n\nBo‘limni tanlang:",
        "language_prompt": "🌐 Tilni tanlang:",
        "language_changed": "Til o‘zbekchaga o‘zgartirildi.",
        "language_back": "Menyuga qaytish",
        "catalog": "Anime katalogi",
        "search": "Anime qidirish",
        "popular": "Mashhur animelar",
        "recent": "Yangi qo'shilganlar",
        "favorites": "Sevimlilarim",
        "profile": "Mening profilim",
        "language": "Tilni o'zgartirish",
        "vip": "VIP sotib olish",
    },
    "ru": {
        "welcome_title": " добро пожаловать в Anime TV!\n\n",
        "welcome_intro": "Ваше путешествие в мир аниме начинается здесь.\n\n",
        "welcome_search": " Ищите аниме\n",
        "welcome_popular": " Находите популярные аниме\n",
        "welcome_recent": " Смотрите новинки каталога\n",
        "welcome_favorites": " Сохраняйте избранное\n",
        "welcome_profile": " Управляйте профилем\n",
        "welcome_community": " Присоединяйтесь к сообществу\n\nВыберите раздел!",
        "welcome_fallback": (
            "Добро пожаловать в Anime TV!\n\n"
            "Ваше путешествие в мир аниме начинается здесь.\n\n"
            "Ищите аниме\nПопулярные аниме\nНовые поступления\n"
            "Сохраняйте избранное\nУправляйте профилем\n\nВыберите раздел!"
        ),
        "menu_title": "🎀 Меню Anime TV\n\n",
        "menu_prompt": "🏆 Выберите раздел и продолжайте знакомство с миром аниме.",
        "menu_callback": "🎀 Anime TV — главное меню\n\nВыберите раздел:",
        "language_prompt": "🌐 Выберите язык:",
        "language_changed": "Язык изменён на русский.",
        "language_back": "В главное меню",
        "catalog": "Каталог аниме",
        "search": "Поиск аниме",
        "popular": "Популярное аниме",
        "recent": "Новые поступления",
        "favorites": "Избранное",
        "profile": "Мой профиль",
        "language": "Сменить язык",
        "vip": "Купить VIP",
    },
    "en": {
        "welcome_title": " welcome to Anime TV!\n\n",
        "welcome_intro": "Your anime adventure starts here.\n\n",
        "welcome_search": " Search for anime\n",
        "welcome_popular": " Discover popular anime\n",
        "welcome_recent": " Browse new additions\n",
        "welcome_favorites": " Save your favorites\n",
        "welcome_profile": " Manage your profile\n",
        "welcome_community": " Join the community\n\nChoose a section!",
        "welcome_fallback": (
            "Welcome to Anime TV!\n\n"
            "Your anime adventure starts here.\n\n"
            "Search for anime\nDiscover popular anime\nBrowse new additions\n"
            "Save your favorites\nManage your profile\n\nChoose a section!"
        ),
        "menu_title": "🎀 Anime TV menu\n\n",
        "menu_prompt": "🏆 Choose a section to explore the world of anime.",
        "menu_callback": "🎀 Anime TV — main menu\n\nChoose a section:",
        "language_prompt": "🌐 Choose a language:",
        "language_changed": "Language changed to English.",
        "language_back": "Back to main menu",
        "catalog": "Anime catalog",
        "search": "Search anime",
        "popular": "Popular anime",
        "recent": "New additions",
        "favorites": "My favorites",
        "profile": "My profile",
        "language": "Change language",
        "vip": "Buy VIP",
    },
}


def normalize_language(language: str | None) -> str:
    if language in SUPPORTED_LANGUAGES:
        return language
    return "uz"


def get_text(key: str, language: str | None = None) -> str:
    return TRANSLATIONS[normalize_language(language)][key]


def get_welcome_parts(language: str | None) -> list[tuple[str | None, str]]:
    translations = TRANSLATIONS[normalize_language(language)]
    return [
        ("brand", "🎀"),
        (None, translations["welcome_title"]),
        ("catalog", "🏆"),
        (None, translations["welcome_intro"]),
        ("search", "🔍"),
        (None, translations["welcome_search"]),
        ("popular", "👀"),
        (None, translations["welcome_popular"]),
        ("recent", "🔝"),
        (None, translations["welcome_recent"]),
        ("favorites", "❤️"),
        (None, translations["welcome_favorites"]),
        ("profile", "✏️"),
        (None, translations["welcome_profile"]),
        ("community", "🌐"),
        (None, translations["welcome_community"]),
    ]
