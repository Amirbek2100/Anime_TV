from __future__ import annotations

from app.config import get_settings


def is_admin_user(user_id: int | None) -> bool:
    if user_id is None:
        return False
    settings = get_settings()
    return user_id in settings.admin_ids
