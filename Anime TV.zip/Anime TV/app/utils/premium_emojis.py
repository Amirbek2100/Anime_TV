from __future__ import annotations

from collections.abc import Sequence
from typing import Literal

from aiogram import Bot
from aiogram.client.session.middlewares.base import (
    BaseRequestMiddleware,
    NextRequestMiddlewareType,
)
from aiogram.client.session.base import Response
from aiogram.methods import EditMessageText, SendMessage
from aiogram.methods.base import TelegramMethod
from aiogram.types import InlineKeyboardButton, MessageEntity, TelegramObject


EMOJI_IDS = {
    "🔍": "5323603386342347579",
    "🔝": "5269490165667089699",
    "👀": "5294301010620078614",
    "📀": "5462956611033117422",
    "🌫": "5148026282923000365",
    "✏️": "5469824826380140690",
    "🎀": "4927046070900360103",
    "🏆": "5429550737656924873",
    "🎄": "6327819143043090120",
    "🧐": "5267415876851744059",
    "😎": "5300996877519444960",
    "🩷": "5978962215426855762",
    "🤍": "5330020716022612294",
    "🖤": "5289689684622977414",
    "🌐": "5330422213860407355",
    "❤️": "5420186420461478924",
}

PREMIUM_EMOJIS = {
    "brand": EMOJI_IDS["🎀"],
    "catalog": EMOJI_IDS["🏆"],
    "search": EMOJI_IDS["🔍"],
    "popular": EMOJI_IDS["👀"],
    "recent": EMOJI_IDS["🔝"],
    "favorites": EMOJI_IDS["❤️"],
    "profile": EMOJI_IDS["✏️"],
    "community": EMOJI_IDS["🌐"],
    "language": EMOJI_IDS["🌐"],
    "about": EMOJI_IDS["🧐"],
    "stats": EMOJI_IDS["😎"],
    "announcement": EMOJI_IDS["🎀"],
    "add": EMOJI_IDS["📀"],
    "delete": EMOJI_IDS["🖤"],
    "edit": EMOJI_IDS["✏️"],
    "list": EMOJI_IDS["🏆"],
    "admin": EMOJI_IDS["🧐"],
}

_EMOJI_TOKENS = tuple(sorted(EMOJI_IDS, key=len, reverse=True))
ButtonStyle = Literal["primary", "success", "danger"]


def premium_button(
    text: str,
    emoji_name: str,
    callback_data: str,
    *,
    style: ButtonStyle | None = "primary",
) -> InlineKeyboardButton:
    return InlineKeyboardButton(
        text=text,
        icon_custom_emoji_id=PREMIUM_EMOJIS[emoji_name],
        callback_data=callback_data,
        style=style,
    )


def _utf16_length(value: str) -> int:
    return len(value.encode("utf-16-le")) // 2


def add_premium_emoji_entities(
    text: str,
    existing_entities: Sequence[MessageEntity] | None = None,
) -> list[MessageEntity]:
    entities = list(existing_entities or [])
    existing_ranges = [
        (entity.offset, entity.offset + entity.length)
        for entity in entities
    ]
    codepoint_index = 0

    while codepoint_index < len(text):
        token = next(
            (
                candidate
                for candidate in _EMOJI_TOKENS
                if text.startswith(candidate, codepoint_index)
            ),
            None,
        )
        if token is None:
            codepoint_index += 1
            continue

        offset = _utf16_length(text[:codepoint_index])
        length = _utf16_length(token)
        end = offset + length
        if not any(offset < existing_end and end > existing_start
                   for existing_start, existing_end in existing_ranges):
            entities.append(
                MessageEntity(
                    type="custom_emoji",
                    offset=offset,
                    length=length,
                    custom_emoji_id=EMOJI_IDS[token],
                )
            )
        codepoint_index += len(token)

    return sorted(entities, key=lambda entity: entity.offset)


class PremiumEmojiMiddleware(BaseRequestMiddleware):
    async def __call__(
        self,
        make_request: NextRequestMiddlewareType[TelegramObject],
        bot: Bot,
        method: TelegramMethod[TelegramObject],
    ) -> Response[TelegramObject]:
        if isinstance(method, (SendMessage, EditMessageText)):
            text = method.text
            if text:
                entities = add_premium_emoji_entities(text, method.entities)
                if len(entities) > len(method.entities or []):
                    method.entities = entities
                    method.parse_mode = None

        return await make_request(bot, method)


def build_premium_text(
    parts: Sequence[tuple[str | None, str]],
) -> tuple[str, list[MessageEntity]]:
    text_parts: list[str] = []
    entities: list[MessageEntity] = []
    offset = 0

    for emoji_name, part in parts:
        part_length = _utf16_length(part)
        if emoji_name is not None:
            entities.append(
                MessageEntity(
                    type="custom_emoji",
                    offset=offset,
                    length=part_length,
                    custom_emoji_id=PREMIUM_EMOJIS[emoji_name],
                )
            )
        text_parts.append(part)
        offset += part_length

    return "".join(text_parts), entities
