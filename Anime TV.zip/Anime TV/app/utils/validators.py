from __future__ import annotations

from typing import Any


def validate_text(value: Any, *, max_length: int = 200, required: bool = False) -> str | None:
    if value is None:
        if required:
            raise ValueError('Value is required')
        return None
    text = str(value).strip()
    if not text and required:
        raise ValueError('Value is required')
    if len(text) > max_length:
        raise ValueError(f'Value must be at most {max_length} characters')
    return text


def validate_year(value: Any) -> int | None:
    if value in (None, ''):
        return None
    year = int(value)
    if year < 1900 or year > 2100:
        raise ValueError('Year must be between 1900 and 2100')
    return year
