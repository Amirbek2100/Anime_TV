#!/usr/bin/env bash
set -Eeuo pipefail

project_dir="/opt/anime-tv"
environment_file="/etc/anime-tv/anime-tv.env"
service_file="/etc/systemd/system/anime-tv.service"
database_dir="/var/lib/anime-tv"
database_seed="/tmp/anime-tv/anime_tv.db"
database_file="${database_dir}/anime_tv.db"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this installer with sudo." >&2
    exit 1
fi

if [[ ! -f "${project_dir}/app/main.py" ]]; then
    echo "Project files are missing from ${project_dir}." >&2
    echo "Upload the project there before running this installer." >&2
    exit 1
fi

if [[ ! -f "${environment_file}" ]]; then
    echo "Create ${environment_file} with your real BOT_TOKEN and settings first." >&2
    echo "Do not put the bot token in source control." >&2
    exit 1
fi

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip

if ! id anime-tv >/dev/null 2>&1; then
    useradd --system --home-dir "${project_dir}" --shell /usr/sbin/nologin anime-tv
fi

install -d -o root -g anime-tv -m 0750 /etc/anime-tv
install -d -o anime-tv -g anime-tv -m 0750 "${database_dir}"
chown root:anime-tv "${environment_file}"
chmod 0640 "${environment_file}"

if [[ ! -e "${database_file}" && -f "${database_seed}" ]]; then
    install -o anime-tv -g anime-tv -m 0640 "${database_seed}" "${database_file}"
fi

python3 -m venv "${project_dir}/.venv"
"${project_dir}/.venv/bin/python" -m pip install --upgrade pip
"${project_dir}/.venv/bin/python" -m pip install -r "${project_dir}/requirements.txt"

chown -R anime-tv:anime-tv "${project_dir}"
install -o root -g root -m 0644 \
    "${project_dir}/deploy/anime-tv.service" \
    "${service_file}"

systemctl daemon-reload
systemctl enable --now anime-tv.service
systemctl --no-pager --full status anime-tv.service
