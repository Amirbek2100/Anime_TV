$ErrorActionPreference = "Stop"

$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$envFile = Join-Path $projectRoot ".env"
if (-not (Test-Path $envFile)) {
    throw "Missing .env file. Create it from .env.example and configure BOT_TOKEN first."
}

$virtualEnvironmentPython = Join-Path $projectRoot ".venv\Scripts\python.exe"
if (Test-Path $virtualEnvironmentPython) {
    $pythonPath = $virtualEnvironmentPython
} else {
    $pythonCommand = Get-Command python -ErrorAction Stop
    $pythonPath = $pythonCommand.Source
}

& $pythonPath -c "import aiogram, sqlalchemy, pydantic_settings" 2>$null
if ($LASTEXITCODE -ne 0) {
    throw "Python dependencies are missing. Install requirements.txt with this interpreter: $pythonPath"
}

$logDirectory = Join-Path $projectRoot "logs"
New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
$logFile = Join-Path $logDirectory "bot.log"
$taskName = "AnimeTVBot"
$userId = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name

$actionArguments = "/d /s /c " + '""{0}" -m app.main >> "{1}" 2>&1"' -f $pythonPath, $logFile
$action = New-ScheduledTaskAction `
    -Execute $env:ComSpec `
    -Argument $actionArguments `
    -WorkingDirectory $projectRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $userId
$settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -MultipleInstances IgnoreNew `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries
$principal = New-ScheduledTaskPrincipal `
    -UserId $userId `
    -LogonType Interactive `
    -RunLevel Limited

Register-ScheduledTask `
    -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal `
    -Description "Runs the Anime TV Telegram bot at user logon and restarts it after failures." `
    -Force | Out-Null

& powercfg.exe /change standby-timeout-ac 0
if ($LASTEXITCODE -ne 0) {
    throw "Could not disable sleep while connected to AC power."
}

Write-Output "Scheduled task '$taskName' is installed for $userId."
Write-Output "The bot starts when this Windows user signs in and restarts after failures."
Write-Output "Sleep while connected to AC power is disabled."
Write-Output "Bot log: $logFile"
