from unittest.mock import AsyncMock

from aiogram.exceptions import TelegramAPIError
from aiogram.methods import SendMessage
from aiogram.types import MessageEntity
import pytest

from app.handlers.admin import (
    _optional_text,
    _send_announcement_to_chat,
    parse_anime_form,
    parse_season_form,
)


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("-", None),
        ("—", None),
        ("", None),
        ("  Naruto  ", "Naruto"),
    ],
)
def test_optional_text_handles_skipped_fields(value, expected):
    assert _optional_text(value) == expected


def test_parse_anime_form_accepts_all_details_in_one_message():
    form = parse_anime_form(
        "Nomi: Naruto\n"
        "Tavsif: Ninja bo‘lishni orzu qiladi\n"
        "Yil: 2002\n"
        "Janrlar: Action, Adventure\n"
        "Poster: https://example.com/poster.jpg\n"
        "Havola: https://example.com/anime"
    )

    assert form == {
        "title": "Naruto",
        "description": "Ninja bo‘lishni orzu qiladi",
        "release_year": 2002,
        "genres": ["Action", "Adventure"],
        "poster_url": "https://example.com/poster.jpg",
        "authorized_link": "https://example.com/anime",
    }


def test_parse_anime_form_requires_title_but_keeps_other_fields_optional():
    assert parse_anime_form("Nomi: Spy x Family") == {
        "title": "Spy x Family",
        "description": None,
        "release_year": None,
        "genres": [],
        "poster_url": None,
        "authorized_link": None,
    }


@pytest.mark.parametrize(
    ("text", "error"),
    [
        ("Tavsif: no title", "Anime nomi majburiy"),
        ("Nomi: Naruto\nYil: two thousand", "Yil son"),
        ("Nomi: Naruto\nYil: 1700", "1880 va 2100"),
        ("Nomi: Naruto\nUnknown: value", "Noma'lum maydon"),
    ],
)
def test_parse_anime_form_reports_invalid_details(text, error):
    with pytest.raises(ValueError, match=error):
        parse_anime_form(text)


def test_parse_season_form_accepts_multiple_episode_link_formats():
    form = parse_season_form(
        "Anime ID: 12\n"
        "Fasl: 1\n"
        "Nomi: Birinchi fasl\n"
        "Qism: 2 | Ikkinchi qism | https://example.com/2\n"
        "Qism: 1 | https://example.com/1"
    )

    assert form == {
        "anime_id": 12,
        "number": 1,
        "title": "Birinchi fasl",
        "episodes": [
            (1, None, "https://example.com/1"),
            (2, "Ikkinchi qism", "https://example.com/2"),
        ],
    }


@pytest.mark.parametrize(
    ("text", "error"),
    [
        ("Anime ID: 1\nFasl: 1", "Kamida bitta Qism"),
        (
            "Anime ID: 1\nFasl: 1\nQism: 1 | https://example.com/1\n"
            "Qism: 1 | https://example.com/2",
            "takrorlanmasin",
        ),
        ("Anime ID: 1\nFasl: 1\nQism: 1 | javascript:alert(1)", "http://"),
    ],
)
def test_parse_season_form_rejects_invalid_episode_data(text, error):
    with pytest.raises(ValueError, match=error):
        parse_season_form(text)


@pytest.mark.asyncio
async def test_announcement_delivery_sends_to_configured_group_chat():
    bot = AsyncMock()

    delivered = await _send_announcement_to_chat(
        bot,
        "Anime TV yangiliklari",
        -1001234567890,
        "configured group",
    )

    assert delivered is True
    bot.send_message.assert_awaited_once_with(
        chat_id=-1001234567890,
        text="Anime TV yangiliklari",
        entities=None,
        parse_mode=None,
    )


@pytest.mark.asyncio
async def test_announcement_delivery_preserves_custom_emoji_entities():
    bot = AsyncMock()
    custom_emoji = MessageEntity(
        type="custom_emoji",
        offset=0,
        length=2,
        custom_emoji_id="5323603386342347579",
    )

    delivered = await _send_announcement_to_chat(
        bot,
        "🔍 Anime yangiligi",
        -1001234567890,
        "configured group",
        [custom_emoji],
    )

    assert delivered is True
    bot.send_message.assert_awaited_once_with(
        chat_id=-1001234567890,
        text="🔍 Anime yangiligi",
        entities=[custom_emoji],
        parse_mode=None,
    )


@pytest.mark.asyncio
async def test_announcement_delivery_reports_telegram_api_failure():
    bot = AsyncMock()
    bot.send_message.side_effect = TelegramAPIError(
        method=SendMessage(chat_id=-1001234567890, text="E'lon"),
        message="Forbidden",
    )

    delivered = await _send_announcement_to_chat(
        bot,
        "E'lon",
        -1001234567890,
        "configured group",
    )

    assert delivered is False
