from __future__ import annotations

from datetime import datetime

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.database.base import Base
from app.services.anime_service import AnimeService
from app.services.season_service import SeasonService
from app.services.user_service import UserService
from app.services.vip_service import (
    VIP_PLANS,
    VipService,
    calculate_discounted_stars,
    parse_vip_invoice_payload,
)


@pytest.fixture
async def session():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Session = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with Session() as db_session:
        yield db_session
    await engine.dispose()


@pytest.mark.asyncio
async def test_create_anime_and_search(session):
    service = AnimeService(session)
    created = await service.create_anime(title="Naruto", description="A ninja story", release_year=2002, genres=["Action", "Adventure"])
    assert created.id is not None
    results, total = await service.search("naruto")
    assert total == 1
    assert results[0].title == "Naruto"


@pytest.mark.asyncio
async def test_favorite_creation_and_removal(session):
    anime_service = AnimeService(session)
    user_service = UserService(session)
    user = await user_service.get_or_create_user(42, "fan")
    anime = await anime_service.create_anime(title="One Piece", description="Pirates", release_year=1999)
    favorite = await anime_service.add_favorite(user.telegram_id, anime.id)
    assert favorite.anime_id == anime.id
    assert await anime_service.is_favorite(user.telegram_id, anime.id) is True
    removed = await anime_service.remove_favorite(user.telegram_id, anime.id)
    assert removed is True
    assert await anime_service.is_favorite(user.telegram_id, anime.id) is False


@pytest.mark.asyncio
async def test_anime_list_pagination_and_genre_updates(session):
    service = AnimeService(session)
    await service.create_anime(title="One Piece", description=None, release_year=1999)
    second = await service.create_anime(title="Naruto", description=None, release_year=2002)

    assert [anime.title for anime in await service.list_recent(limit=1)] == ["Naruto"]
    assert [anime.title for anime in await service.list_recent(limit=1, offset=1)] == ["One Piece"]

    updated = await service.update_genres(second.id, ["Action", "Adventure", "Action"])
    assert updated is not None
    assert [genre.name for genre in updated.genres] == ["Action", "Adventure"]


@pytest.mark.asyncio
async def test_season_creation_and_episode_order(session):
    anime = await AnimeService(session).create_anime(
        title="Naruto",
        description=None,
        release_year=2002,
    )
    service = SeasonService(session)

    season = await service.create_season(
        anime_id=anime.id,
        number=1,
        title="1-fasl",
        episodes=[
            (2, "Ikkinchi qism", "https://example.com/2"),
            (1, None, "https://example.com/1"),
        ],
    )

    assert season is not None
    assert [episode.number for episode in season.episodes] == [1, 2]
    assert [item.title for item in await service.list_seasons(anime.id)] == ["1-fasl"]
    assert await service.get_season_by_number(anime.id, 1) is not None


@pytest.mark.asyncio
async def test_vip_membership_grant_extends_expiration(session):
    user = await UserService(session).get_or_create_user(7654, "vip_user")
    service = VipService(session)

    first = await service.grant_membership(user.telegram_id, days=30)
    assert first is not None
    original_expiry = first.expires_at
    assert await service.is_vip(user.telegram_id)

    extended = await service.grant_membership(user.telegram_id, days=30)
    assert extended is not None
    assert (extended.expires_at - original_expiry).days == 30
    assert await service.grant_membership(8888, days=30) is None


@pytest.mark.asyncio
async def test_vip_user_lookup_accepts_username_with_or_without_at():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Session = async_sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    async with Session() as db_session:
        user = await UserService(db_session).get_or_create_user(
            98765,
            "AnimeFan_1",
        )
        vip_service = VipService(db_session)

        assert await vip_service.get_user_by_username("@animefan_1") == user
        assert await vip_service.get_user_by_username("ANIMEFAN_1") == user
        assert await vip_service.get_user_by_username("@missing_user") is None
    await engine.dispose()


@pytest.mark.parametrize(
    ("key", "days", "stars"),
    [
        ("month", 30, 56),
        ("three_months", 90, 132),
        ("six_months", 180, 226),
        ("year", 365, 454),
    ],
)
def test_vip_stars_plans_and_invoice_payload_validation(key, days, stars):
    plan = VIP_PLANS[key]
    assert (plan.days, plan.stars) == (days, stars)
    assert parse_vip_invoice_payload(
        f"vip:{key}:42",
        telegram_id=42,
        currency="XTR",
        total_amount=stars,
    ) == plan
    assert parse_vip_invoice_payload(
        f"vip:{key}:42",
        telegram_id=43,
        currency="XTR",
        total_amount=stars,
    ) is None
    assert parse_vip_invoice_payload(
        f"vip:{key}:42",
        telegram_id=42,
        currency="UZS",
        total_amount=stars,
    ) is None
    assert parse_vip_invoice_payload(
        f"vip:{key}:42",
        telegram_id=42,
        currency="XTR",
        total_amount=stars + 1,
    ) is None


def test_vip_discount_calculation_rounds_to_valid_stars_amounts():
    assert calculate_discounted_stars(56, 10) == 50
    assert calculate_discounted_stars(56, 99) == 1
    with pytest.raises(ValueError):
        calculate_discounted_stars(56, 100)


@pytest.mark.asyncio
async def test_vip_discount_updates_purchase_price_and_invoice_validation(session):
    service = VipService(session)

    await service.set_discount_percent("month", 10)
    discounted_plan = await service.get_purchase_plan("month")
    assert discounted_plan is not None
    assert discounted_plan.stars == 50
    assert discounted_plan.discount_percent == 10
    assert parse_vip_invoice_payload(
        "vip:month:42:10",
        telegram_id=42,
        currency="XTR",
        total_amount=50,
    ) == discounted_plan
    assert parse_vip_invoice_payload(
        "vip:month:42:10",
        telegram_id=42,
        currency="XTR",
        total_amount=56,
    ) is None

    await service.set_discount_percent("month", 0)
    restored_plan = await service.get_purchase_plan("month")
    assert restored_plan is not None
    assert restored_plan.stars == 56
    assert restored_plan.discount_percent == 0


@pytest.mark.asyncio
async def test_paid_vip_activation_replaces_term_and_is_idempotent(session):
    user = await UserService(session).get_or_create_user(4567, "paid_user")
    service = VipService(session)
    old_membership = await service.grant_membership(user.telegram_id, days=30)
    assert old_membership is not None

    payment_time = datetime.now()
    membership, activated = await service.activate_paid_membership(
        user.telegram_id,
        plan=VIP_PLANS["three_months"],
        currency="XTR",
        total_amount=132,
        telegram_charge_id="charge-123",
    )
    assert membership is not None
    assert activated is True
    assert 89 <= (membership.expires_at - payment_time).days <= 90

    duplicate_membership, duplicate_activated = await service.activate_paid_membership(
        user.telegram_id,
        plan=VIP_PLANS["three_months"],
        currency="XTR",
        total_amount=132,
        telegram_charge_id="charge-123",
    )
    assert duplicate_membership is not None
    assert duplicate_membership.expires_at == membership.expires_at
    assert duplicate_activated is False


@pytest.mark.asyncio
async def test_admin_vip_grant_accepts_custom_days(session):
    user = await UserService(session).get_or_create_user(7655, "custom_vip")
    membership = await VipService(session).grant_membership(
        user.telegram_id,
        days=180,
    )

    assert membership is not None
    assert 179 <= (membership.expires_at - datetime.now()).days <= 180
