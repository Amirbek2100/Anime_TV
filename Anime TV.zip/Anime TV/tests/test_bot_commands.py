from unittest.mock import AsyncMock

import pytest
from aiogram.exceptions import TelegramBadRequest
from aiogram.methods import SetMyCommands

from app.main import ADMIN_COMMANDS, USER_COMMANDS, register_bot_commands


@pytest.mark.asyncio
async def test_register_bot_commands_separates_public_and_admin_scopes():
    bot = AsyncMock()

    await register_bot_commands(
        bot,
        [12345, -1001234567890, 12345],
        group_id=-1001234567890,
    )

    calls = bot.set_my_commands.await_args_list
    assert len(calls) == 5
    assert [call.kwargs["scope"].type for call in calls] == [
        "default",
        "all_private_chats",
        "all_group_chats",
        "chat",
        "chat_member",
    ]
    assert all(call.args[0] == USER_COMMANDS for call in calls[:3])
    assert all(call.args[0] == ADMIN_COMMANDS for call in calls[3:])
    assert calls[3].kwargs["scope"].chat_id == 12345
    assert calls[4].kwargs["scope"].chat_id == -1001234567890
    assert calls[4].kwargs["scope"].user_id == 12345
    assert {command.command for command in USER_COMMANDS} >= {
        "start",
        "menu",
        "help",
        "anime",
        "search",
        "favorites",
        "profile",
    }
    assert {command.command for command in ADMIN_COMMANDS} >= {
        "admin",
        "stats",
        "add_anime",
        "edit_anime",
        "delete_anime",
        "announce",
        "backup",
        "cancel",
    }


@pytest.mark.asyncio
async def test_unavailable_group_scope_does_not_block_private_admin_commands(caplog):
    bot = AsyncMock()
    bot.set_my_commands.side_effect = [
        True,
        True,
        True,
        True,
        TelegramBadRequest(
            method=SetMyCommands(commands=[]),
            message="chat not found",
        ),
    ]

    await register_bot_commands(bot, [12345], group_id=-1001234567890)

    assert bot.set_my_commands.await_count == 5
    assert "admin private-chat commands remain enabled" in caplog.text
