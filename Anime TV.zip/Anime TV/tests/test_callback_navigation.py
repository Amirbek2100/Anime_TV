from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from app.handlers import callbacks


class _SessionContext:
    async def __aenter__(self):
        return object()

    async def __aexit__(self, *_args):
        return None


@pytest.mark.asyncio
async def test_catalog_from_photo_message_sends_anime_list_as_text(monkeypatch):
    anime_list = [
        SimpleNamespace(id=1, title="Naruto"),
        SimpleNamespace(id=2, title="One Piece"),
    ]

    async def get_catalog_page(*_args, **_kwargs):
        return anime_list, len(anime_list), "🏆 Anime katalogi"

    monkeypatch.setattr(
        callbacks,
        "get_session_factory",
        lambda: lambda: _SessionContext(),
    )
    monkeypatch.setattr(callbacks, "_get_section_page", get_catalog_page)
    monkeypatch.setattr(
        callbacks,
        "build_anime_list_keyboard",
        lambda *_args, **_kwargs: "catalog keyboard",
    )

    message = SimpleNamespace(
        photo=[object()],
        edit_reply_markup=AsyncMock(),
        answer=AsyncMock(),
        edit_text=AsyncMock(),
    )
    callback = SimpleNamespace(
        message=message,
        from_user=SimpleNamespace(id=42),
        answer=AsyncMock(),
    )
    state = SimpleNamespace(clear=AsyncMock())

    await callbacks._show_anime_list(callback, state, section="catalog")

    message.edit_reply_markup.assert_awaited_once_with(reply_markup=None)
    message.answer.assert_awaited_once()
    sent_text = message.answer.await_args.args[0]
    sent_options = message.answer.await_args.kwargs
    assert "Naruto" in sent_text
    assert "One Piece" in sent_text
    assert sent_options["reply_markup"] == "catalog keyboard"
    message.edit_text.assert_not_awaited()
    callback.answer.assert_awaited_once()
