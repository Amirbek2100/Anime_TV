from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from app.config import Settings, get_settings, validate_settings


def test_settings_required_bot_token():
    with patch.dict(os.environ, {"BOT_TOKEN": ""}, clear=True):
        with pytest.raises(ValueError, match="BOT_TOKEN"):
            validate_settings()


def test_admin_ids_parse_numeric_csv():
    settings = Settings.model_validate({"BOT_TOKEN": "abc", "ADMIN_IDS": "1,2,3"})
    assert settings.admin_ids == [1, 2, 3]


def test_default_database_url_is_set():
    settings = Settings.model_validate({"BOT_TOKEN": "abc"})
    assert settings.database_url.startswith("sqlite")


def test_get_settings_cache_can_be_cleared_for_reloads():
    with patch.dict(os.environ, {"BOT_TOKEN": "first-token"}, clear=True):
        get_settings.cache_clear()
        assert get_settings().bot_token == "first-token"

    with patch.dict(os.environ, {"BOT_TOKEN": "second-token"}, clear=True):
        get_settings.cache_clear()
        assert get_settings().bot_token == "second-token"
