import pytest
from types import SimpleNamespace

from app.keyboards.main_menu import build_main_menu
from app.keyboards.anime import (
    build_anime_detail_keyboard,
    build_anime_list_keyboard,
    build_episode_list_keyboard,
    build_season_list_keyboard,
)
from app.utils.localization import (
    SUPPORTED_LANGUAGES,
    get_text,
    get_welcome_parts,
)


@pytest.mark.parametrize(
    ("language", "catalog_label", "menu_prompt"),
    [
        ("uz", "Anime katalogi", "Bo‘limni tanlang"),
        ("ru", "Каталог аниме", "Выберите раздел"),
        ("en", "Anime catalog", "Choose a section"),
    ],
)
def test_main_menu_is_translated(language, catalog_label, menu_prompt):
    keyboard = build_main_menu(language=language)

    assert keyboard.inline_keyboard[0][0].text == catalog_label
    assert menu_prompt in get_text("menu_callback", language)
    assert len(get_welcome_parts(language)) > 0


def test_supported_languages_include_uzbek_russian_and_english():
    assert SUPPORTED_LANGUAGES == ("uz", "ru", "en")


@pytest.mark.parametrize("premium_icons", [True, False])
def test_each_main_menu_category_has_a_color_style(premium_icons):
    keyboard = build_main_menu(premium_icons=premium_icons)
    styles = [
        button.style
        for row in keyboard.inline_keyboard
        for button in row
    ]

    assert styles == [
        "danger", "primary",
        "success", "primary",
        "danger", "success",
        "primary", "danger",
    ]


@pytest.mark.parametrize("section", ["catalog", "popular", "recent", "favorites"])
def test_anime_pages_highlight_the_active_category(section):
    list_keyboard = build_anime_list_keyboard([], section=section, total=0)
    detail_keyboard = build_anime_detail_keyboard(
        1,
        section=section,
        is_favorite=False,
    )
    season_keyboard = build_season_list_keyboard(
        [],
        anime_id=1,
        section=section,
        return_offset=0,
    )
    episode_keyboard = build_episode_list_keyboard(
        [],
        anime_id=1,
        season_id=1,
        section=section,
        return_offset=0,
    )

    for keyboard in (
        list_keyboard,
        detail_keyboard,
        season_keyboard,
        episode_keyboard,
    ):
        category_order = ["catalog", "popular", "recent", "favorites"]
        category_callbacks = set(category_order)
        category_buttons = {
            button.callback_data: button
            for row in keyboard.inline_keyboard
            for button in row
            if button.callback_data in category_callbacks
        }
        assert list(category_buttons) == category_order
        assert category_buttons[section].style == "success"
        assert {button.style for button in category_buttons.values()} == {
            "success",
            "primary",
            "danger",
        }
        assert all(
            button.style != "success"
            for callback_data, button in category_buttons.items()
            if callback_data != section
        )


def test_anime_list_items_cycle_through_blue_green_and_red():
    anime_list = [
        SimpleNamespace(id=index, title=f"Anime {index}")
        for index in range(1, 4)
    ]

    keyboard = build_anime_list_keyboard(
        anime_list,
        section="catalog",
        total=3,
    )

    assert [
        keyboard.inline_keyboard[index][0].style
        for index in range(3)
    ] == ["primary", "success", "danger"]
