from aiogram.types import MessageEntity

from app.utils.premium_emojis import (
    EMOJI_IDS,
    add_premium_emoji_entities,
    build_premium_text,
    premium_button,
)
from app.keyboards.main_menu import build_main_menu
from app.keyboards.vip import build_vip_purchase_keyboard
from app.keyboards.anime import (
    build_anime_detail_keyboard,
    build_episode_list_keyboard,
    build_anime_list_keyboard,
)
from app.database.models import Anime, Genre
from app.handlers.admin import build_admin_menu
from app.handlers.callbacks import _format_anime_detail


def test_build_premium_text_creates_custom_emoji_entities_with_utf16_offsets():
    text, entities = build_premium_text([
        (None, "A "),
        ("brand", "🎀"),
        (None, "🔍"),
        ("catalog", "🏆"),
    ])

    assert text == "A 🎀🔍🏆"
    assert [
        (entity.type, entity.offset, entity.length, entity.custom_emoji_id)
        for entity in entities
    ] == [
        ("custom_emoji", 2, 2, "4927046070900360103"),
        ("custom_emoji", 6, 2, "5429550737656924873"),
    ]


def test_add_premium_entities_uses_all_supplied_ids_and_preserves_existing_entities():
    text = " ".join(EMOJI_IDS)
    entities = add_premium_emoji_entities(text)

    assert {entity.custom_emoji_id for entity in entities} == {
        "5323603386342347579",
        "5269490165667089699",
        "5294301010620078614",
        "5462956611033117422",
        "5148026282923000365",
        "5469824826380140690",
        "4927046070900360103",
        "5429550737656924873",
        "6327819143043090120",
        "5267415876851744059",
        "5300996877519444960",
        "5978962215426855762",
        "5330020716022612294",
        "5289689684622977414",
        "5330422213860407355",
        "5420186420461478924",
    }

    first_entity = entities[0]
    preserved = add_premium_emoji_entities(
        text,
        [MessageEntity(
            type="custom_emoji",
            offset=first_entity.offset,
            length=first_entity.length,
            custom_emoji_id=first_entity.custom_emoji_id,
        )],
    )
    assert len(preserved) == len(entities)


def test_custom_emoji_ids_match_the_emoji_stickers_from_telegram():
    assert EMOJI_IDS == {
        "🔍": "5323603386342347579",
        "🔝": "5269490165667089699",
        "👀": "5294301010620078614",
        "📀": "5462956611033117422",
        "🌫": "5148026282923000365",
        "✏️": "5469824826380140690",
        "🎀": "4927046070900360103",
        "🏆": "5429550737656924873",
        "🎄": "6327819143043090120",
        "🧐": "5267415876851744059",
        "😎": "5300996877519444960",
        "🩷": "5978962215426855762",
        "🤍": "5330020716022612294",
        "🖤": "5289689684622977414",
        "🌐": "5330422213860407355",
        "❤️": "5420186420461478924",
    }


def test_main_menu_has_custom_emoji_icons_on_every_button():
    markup = build_main_menu()
    buttons = [button for row in markup.inline_keyboard for button in row]

    assert len(buttons) == 8
    assert all(button.icon_custom_emoji_id for button in buttons)
    assert {button.callback_data for button in buttons} == {
        "catalog",
        "search",
        "popular",
        "recent",
        "favorites",
        "profile",
        "language",
        "vip_info",
    }
    assert [button.style for row in markup.inline_keyboard for button in row] == [
        "danger",
        "primary",
        "success",
        "primary",
        "danger",
        "success",
        "primary",
        "danger",
    ]


def test_admin_menu_has_custom_emoji_icons_on_every_button():
    markup = build_admin_menu()
    buttons = [button for row in markup.inline_keyboard for button in row]

    assert len(buttons) == 9
    assert all(button.icon_custom_emoji_id for button in buttons)
    assert all(button.callback_data.startswith("admin_") for button in buttons)
    assert [button.style for button in buttons] == [
        "primary",
        "success",
        "success",
        "danger",
        "primary",
        "primary",
        "success",
        "success",
        "primary",
    ]


def test_premium_button_uses_the_supplied_custom_emoji_id():
    button = premium_button("Qidiruv", "search", "search")
    assert button.icon_custom_emoji_id == "5323603386342347579"
    assert button.callback_data == "search"
    assert button.style == "primary"


def test_favorite_actions_use_success_and_danger_button_styles():
    add_markup = build_anime_detail_keyboard(
        1,
        section="catalog",
        is_favorite=False,
    )
    remove_markup = build_anime_detail_keyboard(
        1,
        section="catalog",
        is_favorite=True,
    )

    assert add_markup.inline_keyboard[0][0].style == "success"
    assert remove_markup.inline_keyboard[0][0].style == "danger"


def test_anime_detail_shows_season_selection_only_when_seasons_exist():
    no_seasons = build_anime_detail_keyboard(
        3,
        section="catalog",
        is_favorite=False,
    )
    with_seasons = build_anime_detail_keyboard(
        3,
        section="catalog",
        is_favorite=False,
        season_count=2,
    )

    assert all(button.callback_data != "seasons:3:catalog:0"
               for row in no_seasons.inline_keyboard for button in row)
    assert with_seasons.inline_keyboard[0][0].callback_data == "seasons:3:catalog:0"
    assert with_seasons.inline_keyboard[0][0].text == "Fasllar (2)"


def test_episode_buttons_open_watch_links():
    from app.database.models import AnimeEpisode

    markup = build_episode_list_keyboard(
        [
            AnimeEpisode(
                id=1,
                number=1,
                title="Boshlanish",
                watch_url="https://example.com/episode-1",
            )
        ],
        season_id=7,
        anime_id=5,
        section="catalog",
        return_offset=0,
    )

    assert markup.inline_keyboard[0][0].url == "https://example.com/episode-1"
    assert markup.inline_keyboard[1][0].callback_data == "seasons:5:catalog:0"


def test_anime_detail_formats_fields_separately_with_emojis():
    anime = Anime(
        title="Attack on Titan",
        release_year=2013,
        alternative_title="Shingeki no Kyojin",
        status="Yakunlangan",
        age_rating="TV-MA",
        description="Devorlar ortida insoniyat ozodlik uchun kurashadi.",
        genres=[
            Genre(name="Action"),
            Genre(name="Fantasy"),
        ],
    )

    assert _format_anime_detail(anime) == (
        "🏆 Attack on Titan\n"
        "━━━━━━━━━━━━━━\n"
        "📀 Yili: 2013\n"
        "👀 Janrlar: Action, Fantasy\n"
        "🌐 Boshqa nomi: Shingeki no Kyojin\n"
        "🔝 Holati: Yakunlangan\n"
        "🧐 Yosh chegarasi: TV-MA\n\n"
        "🎀 QISQACHA\n"
        "──────────────\n"
        "Devorlar ortida insoniyat ozodlik uchun kurashadi."
    )
    entities = add_premium_emoji_entities(_format_anime_detail(anime))
    assert {
        entity.custom_emoji_id
        for entity in entities
    } == {
        EMOJI_IDS[emoji]
        for emoji in ("🏆", "📀", "👀", "🌐", "🔝", "🧐", "🎀")
    }


def test_vip_purchase_keyboard_has_all_star_prices():
    markup = build_vip_purchase_keyboard()
    buttons = [button for row in markup.inline_keyboard for button in row]

    assert [(button.text, button.callback_data) for button in buttons[:4]] == [
        ("1 oy — 56 ⭐", "vip_buy:month"),
        ("3 oy — 132 ⭐", "vip_buy:three_months"),
        ("6 oy — 226 ⭐", "vip_buy:six_months"),
        ("1 yil — 454 ⭐", "vip_buy:year"),
    ]


def test_vip_purchase_keyboard_shows_admin_discount_price():
    from app.services.vip_service import VipPlan

    markup = build_vip_purchase_keyboard(
        [VipPlan("month", "1 oy", 30, 50, discount_percent=10)]
    )

    assert markup.inline_keyboard[0][0].text == "1 oy — 50 ⭐ (-10%)"


def test_anime_list_keyboard_keeps_page_and_section_in_navigation():
    markup = build_anime_list_keyboard(
        [Anime(id=12, title="Naruto")],
        section="favorites",
        offset=8,
        total=18,
    )
    buttons = [button for row in markup.inline_keyboard for button in row]

    assert buttons[0].callback_data == "anime:12:favorites:8"
    assert [button.callback_data for button in markup.inline_keyboard[1]] == [
        "list:favorites:0",
        "list:favorites:16",
    ]
