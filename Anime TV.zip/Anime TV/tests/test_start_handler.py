from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from aiogram.exceptions import TelegramBadRequest
from aiogram.methods import SendPhoto

from app.handlers import start


class _SessionContext:
    async def __aenter__(self):
        return object()

    async def __aexit__(self, *_args):
        return None


@pytest.mark.asyncio
async def test_start_retries_with_basic_menu_when_telegram_rejects_premium_icons(monkeypatch):
    service = SimpleNamespace(get_or_create_user=AsyncMock())
    monkeypatch.setattr(start, "get_session_factory", lambda: lambda: _SessionContext())
    monkeypatch.setattr(start, "UserService", lambda _session: service)

    message = SimpleNamespace(
        from_user=SimpleNamespace(id=42, username="user", first_name="User"),
        answer_photo=AsyncMock(
            side_effect=[
                TelegramBadRequest(
                    method=SendPhoto(chat_id=42, photo="banner.jpg"),
                    message="BUTTON_TYPE_INVALID",
                ),
                None,
            ]
        ),
        answer=AsyncMock(),
    )
    state = SimpleNamespace(clear=AsyncMock())

    await start.start_command(message, state)

    assert message.answer_photo.await_count == 2
    initial_message = message.answer_photo.await_args_list[0].kwargs
    assert initial_message["photo"].path == start.WELCOME_BANNER
    assert initial_message["caption_entities"]

    fallback = message.answer_photo.await_args_list[1].kwargs
    assert fallback["photo"].path == start.WELCOME_BANNER
    assert fallback["caption"]
    assert "caption_entities" not in fallback
    message.answer.assert_not_awaited()
    assert all(
        button.icon_custom_emoji_id is None
        for row in fallback["reply_markup"].inline_keyboard
        for button in row
    )
    service.get_or_create_user.assert_awaited_once()
