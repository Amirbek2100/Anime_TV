from __future__ import annotations

from datetime import datetime

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.database.base import Base
from app.database.models import User
from app.services.user_service import UserService


@pytest.fixture
async def session():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Session = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with Session() as db_session:
        yield db_session
    await engine.dispose()


@pytest.mark.asyncio
async def test_get_or_create_user_creates_new_user(session):
    service = UserService(session)
    user = await service.get_or_create_user(12345, "alice", "Alice")
    assert user.telegram_id == 12345
    assert user.username == "alice"
    assert user.first_name == "Alice"


@pytest.mark.asyncio
async def test_get_or_create_user_handles_existing_user(session):
    service = UserService(session)
    await service.get_or_create_user(999, "olduser", "Old")
    updated = await service.get_or_create_user(999, "newuser", "New")
    assert updated.username == "newuser"
    assert updated.first_name == "New"


@pytest.mark.asyncio
async def test_get_or_create_user_preserves_existing_language_unless_changed(session):
    service = UserService(session)
    await service.get_or_create_user(1001, preferred_language="ru")

    updated = await service.get_or_create_user(1001, username="anime_fan")

    assert updated.preferred_language == "ru"
    assert await service.get_preferred_language(1001) == "ru"


@pytest.mark.asyncio
async def test_notification_recipients_include_only_active_opted_in_users(session):
    session.add_all([
        User(telegram_id=101),
        User(telegram_id=102, is_active=False),
        User(telegram_id=103, notification_preference="disabled"),
    ])
    await session.commit()

    recipients = await UserService(session).get_notification_recipients()

    assert recipients == [101]
